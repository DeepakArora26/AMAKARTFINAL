package com.amakart.controller;

import com.amakart.dto.CategoryDTO;
import com.amakart.dto.ProductDTO;
import com.amakart.dto.SubCategoryDTO;
import com.amakart.model.Category;
import com.amakart.model.Orders;
import com.amakart.model.Product;
import com.amakart.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@Controller
public class AdminController {


    @Autowired
    AdminService adminService;

    private  HttpHeaders headers;
    private  HttpEntity<?> requestEntity;


    final String baseURI = "http://localhost:8080/";

    @Autowired
    RestTemplate restTemplate;





    @GetMapping("/adminhome")
    public ModelAndView showAdminHome(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {

        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);

        modelAndView.setViewName("adminHome");
        try {
            modelAndView.addObject("OrderCount", restTemplate.exchange(baseURI + "admin/stats/ordercount", HttpMethod.GET, requestEntity, Map.class).getBody().get("Order Count"));
            modelAndView.addObject("UserCount", restTemplate.exchange(baseURI + "admin/stats/usercount", HttpMethod.GET, requestEntity, Map.class).getBody().get("User Count"));
            modelAndView.addObject("LatestOrders", restTemplate.exchange(baseURI + "admin/stats/orders", HttpMethod.GET, requestEntity, Orders[].class).getBody());
            modelAndView.addObject("LatestProducts", restTemplate.exchange(baseURI + "admin/stats/products", HttpMethod.GET, requestEntity, Product[].class).getBody());
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());
        }

        catch(HttpClientErrorException e)
        {
            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }
        return modelAndView;
    }


    @GetMapping("/addCategory")
    public ModelAndView showAddCategory(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {
        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);
        modelAndView.setViewName("categoryAddition");

        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);
        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());

        }
        catch(HttpClientErrorException e)
        {
            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }


        return modelAndView;
    }


    @PostMapping("/categoryAddition")
    public RedirectView addCategory(@ModelAttribute CategoryDTO categoryDTO, RedirectAttributes redirectAttributes, RedirectView redirectView,@CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {

        headers = new HttpHeaders();
        headers.add("JWTKey", jwtkey);
        requestEntity = new HttpEntity<CategoryDTO>(categoryDTO,headers);


        try {

            redirectAttributes.addFlashAttribute("CategoryId",restTemplate.exchange(baseURI + "admin/category", HttpMethod.POST ,requestEntity, Category.class).getBody().getId());
        }

        catch (HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("Category With Same Name is Already Present.")) {
                redirectAttributes.addFlashAttribute("categoryError", "Error");
            }
        }
        redirectView.setUrl("/addCategory");
        return redirectView;

    }


    @GetMapping("/addSubCategory")
    public ModelAndView showAddSubCategory(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {

        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        modelAndView.setViewName("subCategoryAddition");

        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);

        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());
            modelAndView.addObject("CategoriesList", restTemplate.getForEntity(baseURI + "categories", Category[].class).getBody());

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("There are No Categories Present")) {
                modelAndView.setViewName("coming_soon");
            }

            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }

        return modelAndView;
    }


    @PostMapping("/subCategoryAddition")
    public RedirectView addSubCategory(@ModelAttribute("category") SubCategoryDTO subCategoryDTO, @RequestParam String CategoryName, RedirectAttributes redirectAttributes, RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {

        try {


            headers = new HttpHeaders();
            headers.add("JWTKey", jwtkey);
            requestEntity = new HttpEntity<SubCategoryDTO>(subCategoryDTO,headers);




            redirectAttributes.addFlashAttribute("SubCategoryId",restTemplate.exchange(baseURI + "admin/subcategory/"+CategoryName.split(". ")[0], HttpMethod.POST ,requestEntity, Category.class).getBody().getId());
            redirectAttributes.addFlashAttribute("SubCategory","Success");
        }

        catch (HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("Category With Same Name is Already Present.")) {
                redirectAttributes.addFlashAttribute("SubCategory", "CategoryPresent");
            }
            if (e.getLocalizedMessage().contains("Sub-Category With Same Name is Already Present.")) {

                redirectAttributes.addFlashAttribute("SubCategory", "SubCategoryIsPresent");
            }
        }
        redirectView.setUrl("/addSubCategory");
        return redirectView;
    }




    @GetMapping("/addProduct")
    public ModelAndView showAddProduct(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {

        modelAndView.setViewName("productAddition");
        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "fadmin/irstname", HttpMethod.GET, requestEntity, String.class).getBody());

        } catch (final HttpClientErrorException e) {

            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }

        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);

        modelAndView.addObject("SubCategoriesList",restTemplate.getForEntity(baseURI + "subcategories", Category[].class).getBody());

        return modelAndView;
    }


    @PostMapping("/productAddition")
    public RedirectView AddProduct(RedirectView redirectView, RedirectAttributes redirectAttributes, @ModelAttribute("product") ProductDTO productDTO, @RequestParam String SubCategoryName, @RequestParam String attributes,@CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {



        try {



            headers = new HttpHeaders();
            headers.add("JWTKey", jwtkey);
            requestEntity = new HttpEntity<ProductDTO>(productDTO,headers);

            String productId = restTemplate.exchange(baseURI + "admin/product/"+SubCategoryName.split(". ")[0], HttpMethod.POST ,requestEntity, Product.class).getBody().getProductId();
            redirectAttributes.addFlashAttribute("ProductId",productId);

            adminService.addAttributesToProduct(attributes.split("\""),productId,headers);

            redirectAttributes.addFlashAttribute("Product","Success");
        }

        catch (HttpClientErrorException e) {

            if (e.getStatusCode().value() == 403) {
                redirectView.setUrl("/login");
            }

            if (e.getLocalizedMessage().contains("Product With Given Name Is Already Present.")) {
                redirectAttributes.addFlashAttribute("Product", "NameError");

            }

            if (e.getLocalizedMessage().contains("Product With Given Id Is Already Present.")) {
                redirectAttributes.addFlashAttribute("Product", "IdError");
            }
        }


        redirectView.setUrl("/addProduct");
        return redirectView;
    }


    @GetMapping("/removeCategory")
    public ModelAndView showRemoveCategory(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {
        modelAndView.setViewName("categoryDeletion");

        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());

        } catch (final HttpClientErrorException e) {

            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }


        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);

        try {

            modelAndView.addObject("CategoriesList", restTemplate.getForEntity(baseURI + "categories", Category[].class).getBody());

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("There are No Categories Present")) {
                modelAndView.setViewName("coming_soon");
            }
        }

        return modelAndView;
    }


    @PostMapping("/categoryDeletion")
    public RedirectView removeCategory(RedirectView redirectView, RedirectAttributes redirectAttributes, String categoryName,@CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {
        headers = new HttpHeaders();
        headers.add("JWTKey", jwtkey);
        requestEntity = new HttpEntity<String>(headers);

        redirectAttributes.addFlashAttribute("CategoryDeletion",restTemplate.exchange(baseURI + "admin/category/"+categoryName.split(". ")[0], HttpMethod.DELETE ,requestEntity, Map.class).getBody().containsValue("All the related Sub-Categories and it's Products have been deleted"));

        redirectView.setUrl("/removeCategory");
        return redirectView;
    }





    @GetMapping("/removeSubCategory")
    public ModelAndView showRemoveSubCategory(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {
        modelAndView.setViewName("subCategoryDeletion");
        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());

        } catch (final HttpClientErrorException e) {

            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }
        }

        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);

        modelAndView.addObject("SubCategoriesList",restTemplate.getForEntity(baseURI + "subcategories", Category[].class).getBody());


        return modelAndView;
    }




    @PostMapping("/subCategoryDeletion")
    public RedirectView removeSubCategory(RedirectView redirectView, RedirectAttributes redirectAttributes, String subCategoryName,@CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {

        headers = new HttpHeaders();
        headers.add("JWTKey", jwtkey);
        requestEntity = new HttpEntity<String>(headers);


        redirectAttributes.addFlashAttribute("SubCategoryDeletion",restTemplate.exchange(baseURI + "admin/subcategory/"+subCategoryName.split(". ")[0], HttpMethod.DELETE ,requestEntity, Map.class).getBody().containsValue("All the related Products have been deleted"));


        redirectView.setUrl("/removeSubCategory");
        return redirectView;
    }


    @GetMapping("/removeProduct")
    public ModelAndView showRemoveProduct(ModelAndView modelAndView,@CookieValue(name = "JWTKey", defaultValue = "") String JWTKey)
    {

        modelAndView.setViewName("productDeletion");
        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        try {
            modelAndView.addObject("UserName", restTemplate.exchange(baseURI + "admin/firstname", HttpMethod.GET, requestEntity, String.class).getBody());

            modelAndView.addObject("ProductsList",restTemplate.getForEntity(baseURI + "products", Product[].class).getBody());


        } catch (final HttpClientErrorException e) {

            if(e.getStatusCode().value() == 403)
            {
                modelAndView.setViewName("Error_404`");
            }

            if(e.getLocalizedMessage().contains("Product Not Found With Given Id"))
            {
            }


        }


        modelAndView = adminService.getDisplayOptionsinfo(modelAndView);


        return modelAndView;
    }




    @PostMapping("/productDeletion")
    public RedirectView removeProduct(RedirectView redirectView, RedirectAttributes redirectAttributes, String productName,@CookieValue(name = "JWTKey", defaultValue = "") String jwtkey)
    {

        headers = new HttpHeaders();
        headers.add("JWTKey", jwtkey);
        requestEntity = new HttpEntity<String>(headers);

        redirectAttributes.addFlashAttribute("ProductDeletion",restTemplate.exchange(baseURI + "admin/product/"+productName.split(". ")[0], HttpMethod.DELETE ,requestEntity, Map.class).getBody().containsValue("Product And all it's related Attributes And Images Have Been Deleted"));

        redirectView.setUrl("/removeProduct");
        return redirectView;
    }




}
