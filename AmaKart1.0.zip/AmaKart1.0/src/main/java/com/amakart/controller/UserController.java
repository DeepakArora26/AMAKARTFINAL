package com.amakart.controller;

import com.amakart.dto.UserDTO;
import com.amakart.model.*;
import com.amakart.service.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Controller
public class UserController {


    final String baseURI = "http://localhost:8080/";
    @Autowired
    AdminService adminService;
    @Autowired
    RestTemplate restTemplate;
    private HttpHeaders headers;
    private HttpEntity<?> requestEntity;

    @GetMapping("/")
    public ModelAndView showHome(ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {

        modelAndView.setViewName("Home");

        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);

        try {

            modelAndView.addObject("firstPromotedCategory", restTemplate.getForEntity(baseURI + "features/promotedcategory", Category.class).getBody());

            modelAndView.addObject("firstPromotedSubcategories", restTemplate.getForEntity(baseURI + "features/promotedsubcategories", Category[].class).getBody());

            modelAndView.addObject("FirstPromoSubCatMessage", "Available");

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("There are No Sub-Categories Present")) {
                modelAndView.addObject("FirstPromoSubCatMessage", "Coming Soon");
            }


        }


        return modelAndView;

    }


    @PostMapping("/checkJWTlogin")
    public RedirectView getJWTToken(@ModelAttribute AuthenticationRequest authenticationRequest, RedirectView redirectView, RedirectAttributes redirectAttributes, HttpServletResponse response) {


        Map<String, String> userDetails = new HashMap<>();
        userDetails.put("username", authenticationRequest.getUsername());
        userDetails.put("password", authenticationRequest.getPassword());

        redirectView.setUrl("/");

        try {

            AuthenticationResponse authenticationResponse = restTemplate.postForEntity(baseURI + "features/genrateJWT", userDetails, AuthenticationResponse.class).getBody();
            Cookie cookie = new Cookie("JWTKey", authenticationResponse.getJwt());
            response.addCookie(cookie);

            headers = new HttpHeaders();
            headers.add("JWTKey", authenticationResponse.getJwt());
            requestEntity = new HttpEntity<String>(headers);


            String authorities = restTemplate.exchange(baseURI + "role", HttpMethod.GET, requestEntity, String.class).getBody();
            if (authorities.contains("ADMIN")) {
                redirectView.setUrl("/adminhome");
            }


        } catch (final HttpClientErrorException e) {

            redirectAttributes.addFlashAttribute("errorMsg", "Your username and password are invalid.");

            redirectView.setUrl("/login");
        }


        return redirectView;
    }


    @GetMapping("/subcategory")
    public ModelAndView showSubCategory(@RequestParam @Valid int parentId, ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {

        modelAndView.setViewName("subcategories");

        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);


        Map<String, Integer> subCategoryDetails = new HashMap<>();
        subCategoryDetails.put("parentId", parentId);

        try {

            modelAndView.addObject("categoryName", restTemplate.postForEntity(baseURI + "features/categoryname", subCategoryDetails, String.class).getBody());

            modelAndView.addObject("subCategoriesList", restTemplate.getForEntity(baseURI + "categories/" + parentId, Category[].class).getBody());


            modelAndView.addObject("Message", "Available");

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("There are No Sub-Categories Present")) {
                modelAndView.addObject("Message", "Coming Soon");
            }

            if (e.getLocalizedMessage().contains("Category Not Found With Given Id")) {
                modelAndView.setViewName("Error_404");
            }

        }


        return modelAndView;

    }


    @GetMapping("/products")
    public ModelAndView showProducts(@RequestParam int subCategoryId, ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {


        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);


        modelAndView.setViewName("products");

        try {
            Map<String, Integer> productDetails = new HashMap<>();
             productDetails.put("subCategoryId", subCategoryId);
            modelAndView.addObject("subCategoryName", restTemplate.postForEntity(baseURI + "features/categoryname", productDetails, String.class).getBody());
            modelAndView.addObject("categoryName", restTemplate.postForEntity(baseURI + "features/categorynameofsubcategory", productDetails, String.class).getBody());

            modelAndView.addObject("productsList", restTemplate.getForEntity(baseURI + subCategoryId + "/products", Product[].class).getBody());

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("Sub Category Not Found With Given Id") || e.getLocalizedMessage().contains("Category Not Found With Given Id")) {
                modelAndView.setViewName("Error_404");
            }

            if (e.getLocalizedMessage().contains("There are No Products Present")) {
                modelAndView.addObject("Message", "Coming Soon");
            }
        }


        return modelAndView;

    }

    @GetMapping("/productDetail")
    public ModelAndView showProductDetails(@RequestParam String productId, ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {


        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);


        modelAndView.setViewName("productDetails");


        try {
            Map<String, String> productDetails = new HashMap<>();
            productDetails.put("productId", productId);

            modelAndView.addObject("productDetail", restTemplate.getForEntity(baseURI + "product/" + productId, Product.class).getBody());
            modelAndView.addObject("categoryName", restTemplate.postForEntity(baseURI + "features/categorynameofproduct", productDetails, String.class).getBody());
            modelAndView.addObject("subCategoryName", restTemplate.postForEntity(baseURI + "features/subcategorynameofproduct", productDetails, String.class).getBody());


        } catch (HttpClientErrorException e) {
            if (e.getLocalizedMessage().contains("Product Not Found With Given")) {
                modelAndView.setViewName("Error_404");
            }
        }


        return modelAndView;

    }

    @PostMapping("/addtocart")
    public RedirectView addToCart(@RequestParam String productId, @RequestParam int productQuantity, RedirectAttributes redirectAttributes, RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey) {


        try {
            ProductRequest productRequest = new ProductRequest();
            productRequest.setQuantity(productQuantity);

            headers = new HttpHeaders();
            headers.add("JWTKey", JWTKey);

            requestEntity = new HttpEntity<>(productRequest, headers);


            restTemplate.exchange(baseURI + "/cart/product/" + productId, HttpMethod.POST, requestEntity, String.class).getBody();

            redirectAttributes.addFlashAttribute("ProductAdditionMessage", "Product Has Been Successfully Added Into The Cart");

            redirectView.setUrl("/productDetail");
            redirectView.addStaticAttribute("productId", productId);

        } catch (HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("Sorry. We don't have this much quantity")) {
                redirectAttributes.addFlashAttribute("ProductAdditionMessage",
                        "Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
            }

            if(e.getStatusCode().value() == 403)
            {
                redirectView.setUrl("/showlogin");
            }

        }


        return redirectView;


    }

    @GetMapping("/cart")
    public ModelAndView showCart(ModelAndView modelAndView, @ModelAttribute("Checkout") String Checkout, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {

        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);
        modelAndView.setViewName("cart");


        if (modelAndView.getModelMap().containsValue("Not-Logged In")) {
            modelAndView.setViewName("login");
        }

        if (Checkout.isEmpty()) {
            modelAndView.addObject("Checkout", "Not Available");
        }


        return modelAndView;

    }

    @PostMapping("/checkout")
    public RedirectView checkout(RedirectAttributes redirectAttributes, RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey) {


        try {

            headers = new HttpHeaders();
            headers.add("JWTKey", JWTKey);
            requestEntity = new HttpEntity<String>(headers);

            redirectAttributes.addFlashAttribute("OrderHistory", restTemplate.exchange(baseURI + "/checkout", HttpMethod.GET, requestEntity, Orders.class).getBody());
            redirectView.setUrl("/orders");

        } catch (HttpClientErrorException e) {


            redirectAttributes.addFlashAttribute("Checkout", "Error");
            redirectView.setUrl("/cart");

            if(e.getStatusCode().value() == 403)
            {
                redirectView.setUrl("/showlogin");
            }


        }


        return redirectView;

    }

    @GetMapping("/orders")
    public ModelAndView order(ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {


        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);

        if (modelAndView.getModelMap().containsValue("Not-Logged In")) {
            modelAndView.setViewName("login");
        }

        modelAndView.setViewName("Orders");
        return modelAndView;

    }

    @PostMapping("/deleteItem")
    public RedirectView deleteProduct(@RequestParam String productId, RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey) {


        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);

        requestEntity = new HttpEntity<>(headers);


        restTemplate.exchange(baseURI + "/cart/product/" + productId, HttpMethod.DELETE, requestEntity, String.class).getBody();


        redirectView.setUrl("/cart");

        return redirectView;

    }

    @PostMapping("/updateCart")
    public RedirectView updateCart(@RequestParam String productId, @RequestParam int productQuantity,
                                   RedirectAttributes redirectAttributes, RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey) {


        try {
            ProductRequest productRequest = new ProductRequest();
            productRequest.setQuantity(productQuantity);

            headers = new HttpHeaders();
            headers.add("JWTKey", JWTKey);

            requestEntity = new HttpEntity<>(productRequest, headers);


            restTemplate.exchange(baseURI + "/cart/product/" + productId, HttpMethod.PUT, requestEntity, String.class).getBody();

            redirectAttributes.addFlashAttribute("ProductAdditionMessage", "Quantity Updated Successfully");

        } catch (HttpClientErrorException e) {

            redirectAttributes.addFlashAttribute("ProductAdditionMessage",
                    "Sorry It Seems We Don't Have That Much Stock Right Now. Try Again With The Lesser Quantity");
        }


        redirectAttributes.addFlashAttribute("productId", productId);
        redirectView.setUrl("/cart");
        return redirectView;

    }


    @GetMapping("/refreshCart")
    public RedirectView refreshCart(RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey) {


        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);

        requestEntity = new HttpEntity<>(headers);


        restTemplate.exchange(baseURI + "/cart/removeoutofstock", HttpMethod.DELETE, requestEntity, String.class);


        redirectView.setUrl("/cart");
        return redirectView;

    }


    @GetMapping("/contactUs")
    public ModelAndView contactUs(ModelAndView modelAndView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,HttpServletResponse response) {


        modelAndView = adminService.commonDetails(modelAndView, JWTKey,response);

        modelAndView.setViewName("contactUs");
        return modelAndView;

    }


    @GetMapping("/login")
    public RedirectView login(RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey,@ModelAttribute("errorMsg") String errorMsg,RedirectAttributes redirectAttributes) {


        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);
        requestEntity = new HttpEntity<String>(headers);

        try {

            String authorities = restTemplate.exchange(baseURI + "role", HttpMethod.GET, requestEntity, String.class).getBody();
            if (authorities.contains("ADMIN")) {
                redirectView.setUrl("/adminhome");
            }

            if (authorities.contains("USER")) {
                redirectView.setUrl("/");
            }


        } catch (HttpClientErrorException e) {
            redirectAttributes.addFlashAttribute("errorMsg", "Your username and password are invalid.");


            redirectView.setUrl("/showlogin");

        }

        return redirectView;

    }



    @GetMapping("/showlogin")
    public ModelAndView showLogin(ModelAndView modelAndView) {

        modelAndView.setViewName("login");
        return modelAndView;
    }



    @GetMapping("/logout")
    public RedirectView logout(RedirectView redirectView, @CookieValue(name = "JWTKey", defaultValue = "") String JWTKey, HttpServletResponse response) {

        JwtToken jwt = new JwtToken();
        jwt.setInvalidJwtToken(JWTKey);
        headers = new HttpHeaders();
        headers.add("JWTKey", JWTKey);

        requestEntity = new HttpEntity<>(jwt, headers);


        restTemplate.exchange(baseURI + "logoutToken", HttpMethod.POST, requestEntity, Boolean.class);
        Cookie cookie = new Cookie("JWTKey", JWTKey);
        cookie.setMaxAge(0);
        response.addCookie(cookie);


        redirectView.setUrl("/");
        return redirectView;
    }


    @PostMapping("/register")
    public RedirectView register(RedirectAttributes redirectAttributes, RedirectView redirectView, @ModelAttribute UserDTO userDTO) {


        try {

            requestEntity = new HttpEntity<>(userDTO);


            restTemplate.exchange(baseURI + "register", HttpMethod.POST, requestEntity, String.class);
            redirectAttributes.addFlashAttribute("registerMessage", "Registration Successful. You Can now Login");


        } catch (HttpClientErrorException e) {
            if (e.getLocalizedMessage().contains("UserName Already Exists.")) {
                redirectAttributes.addFlashAttribute("registerMessage", "This Email-Id is Already Registered. Try Again with different Email-id");
            }
        }


        redirectView.setUrl("/showlogin");
        return redirectView;

    }


    @ExceptionHandler
    void handleIllegalArgumentException(IllegalArgumentException e, HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.BAD_REQUEST.value());
    }


    @ExceptionHandler
    void handleMissingRequestParameterException(MissingServletRequestParameterException e, HttpServletResponse response) throws IOException {
        response.sendError(HttpStatus.BAD_REQUEST.value());
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    @ResponseStatus(value = HttpStatus.METHOD_NOT_ALLOWED)
    ModelAndView handleHttpRequestMethodNotSupportedException(HttpRequestMethodNotSupportedException e, HttpServletResponse response, ModelAndView modelAndView) throws IOException {
      modelAndView.setViewName("Error_404");
      return modelAndView;
    }



}
