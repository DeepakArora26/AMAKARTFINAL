package com.amakart.dto;


import javax.validation.constraints.NotEmpty;

public class SubCategoryDTO {

    @NotEmpty(message = "Name is required")
    private String name;
    @NotEmpty(message = "Image Name is required")
    private String image;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
