package com.amakart.dto;


import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class ProductDTO {

    @NotEmpty(message = "Product Id is required")
    private String productId;
    @NotEmpty(message = "Product Name is required")
    private String productName;
    @NotNull(message = "Product MRP is required")
    @Min(value = 1, message = "Product MRP Cannot be <=0")
    private Double productMrp;
    @NotNull(message = "Product Discounted Price is required")
    @Min(value = 1, message = "Product Discounted Price Cannot be <=0")
    private Double productDiscountedPrice;
    @Min(value = 1, message = "Product Stock Cannot be <=0")
    private int productAvailableStock;
    @NotEmpty(message = "Product Thumbnail is required")
    private String thumbnail;


    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Double getProductMrp() {
        return productMrp;
    }

    public void setProductMrp(Double productMrp) {
        this.productMrp = productMrp;
    }

    public Double getProductDiscountedPrice() {
        return productDiscountedPrice;
    }

    public void setProductDiscountedPrice(Double productDiscountedPrice) {
        this.productDiscountedPrice = productDiscountedPrice;
    }

    public int getProductAvailableStock() {
        return productAvailableStock;
    }

    public void setProductAvailableStock(int productAvailableStock) {
        this.productAvailableStock = productAvailableStock;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

}
