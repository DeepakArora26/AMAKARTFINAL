package com.amakart.dto;

import javax.validation.constraints.NotEmpty;

public class CategoryDTO {

   @NotEmpty(message = "Name is required")
   String name;
   boolean promoted;
   String promotedThumbnail;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isPromoted() {
        return promoted;
    }

    public void setPromoted(boolean promoted) {
        this.promoted = promoted;
    }

    public String getPromotedThumbnail() {
        return promotedThumbnail;
    }

    public void setPromotedThumbnail(String promotedThumbnail) {
        this.promotedThumbnail = promotedThumbnail;
    }
}
