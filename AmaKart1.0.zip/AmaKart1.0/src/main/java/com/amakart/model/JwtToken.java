package com.amakart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class JwtToken {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String invalidJwtToken;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInvalidJwtToken() {
        return invalidJwtToken;
    }

    public void setInvalidJwtToken(String invalidJwtToken) {
        this.invalidJwtToken = invalidJwtToken;
    }
}
