package com.amakart.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.stereotype.Component;

import javax.persistence.*;

@Component
@Entity
public class CartItem {

	@ManyToOne
	@JoinColumn(name = "cartId")
	@JsonIgnore
	private Cart cart;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String productId;
	private String productName;
	private Double productPrice;
	@Column(columnDefinition = "INT(11) UNSIGNED")
	private int productPurchasedQuantity;
	private String productImage;
	private Double productTotalPrice;
	private boolean outOfStock;



	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Cart getCart() {
		return cart;
	}

	public void setCart(Cart cart) {
		this.cart = cart;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Double getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(Double productPrice) {
		this.productPrice = productPrice;
	}

	public int getProductPurchasedQuantity() {
		return productPurchasedQuantity;
	}

	public void setProductPurchasedQuantity(int productPurchasedQuantity) {
		this.productPurchasedQuantity = productPurchasedQuantity;
	}

	public String getProductImage() {
		return productImage;
	}

	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}

	public Double getProductTotalPrice() {
		return productTotalPrice;
	}

	public void setProductTotalPrice() {

		productTotalPrice = productPrice * productPurchasedQuantity;
	}

	public boolean isOutOfStock() {
		return outOfStock;
	}

	public void setOutOfStock(boolean outOfStock) {
		this.outOfStock = outOfStock;
	}

	@Override
	public String toString() {
		return "CartItem{" +
				"id=" + id +
				", productId='" + productId + '\'' +
				", productName='" + productName + '\'' +
				", productPrice=" + productPrice +
				", productPurchasedQuantity=" + productPurchasedQuantity +
				", productImage='" + productImage + '\'' +
				", productTotalPrice=" + productTotalPrice +
				", outOfStock=" + outOfStock +
				'}';
	}
}
