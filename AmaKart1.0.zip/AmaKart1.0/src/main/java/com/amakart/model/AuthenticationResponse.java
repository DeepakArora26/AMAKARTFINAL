package com.amakart.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

import java.io.Serializable;


public class AuthenticationResponse implements Serializable {

    private  String jwt;


    public String getJwt() {
        return jwt;
    }


    public AuthenticationResponse(String jwt) {
        this.jwt = jwt;
    }


    public AuthenticationResponse() {
    }



}
