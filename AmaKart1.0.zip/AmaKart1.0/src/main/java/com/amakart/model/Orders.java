package com.amakart.model;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonBackReference;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Component
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderNo;
	private Double cartTotal;
	private Date orderDate;
	@OneToMany(mappedBy = "orderHistory", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<OrderItem> orderDetailList = new ArrayList<>();
	@ManyToOne
	private User user;

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}


	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItem> getOrderDetailList() {
		return orderDetailList;
	}

	public void addProduct(OrderItem orderdetail) {
		orderdetail.setOrderHistory(this);
		orderDetailList.add(orderdetail);
	}

	public void setOrderDetailList(List<OrderItem> orderDetailList) {
		this.orderDetailList = orderDetailList;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "OrderHistory [orderNo=" + orderNo + ", cartTotal=" + cartTotal
				+ ", orderDate=" + orderDate + ", orderDetailList=" + orderDetailList + "]";
	}

}
