package com.amakart.service;

import org.springframework.http.HttpHeaders;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletResponse;

public interface AdminService {

    void addAttributesToProduct(String[] attributes, String productId, HttpHeaders headers);

    ModelAndView getDisplayOptionsinfo(ModelAndView modelAndView);

    ModelAndView commonDetails(ModelAndView modelAndView, String jwtKey,HttpServletResponse response);

}