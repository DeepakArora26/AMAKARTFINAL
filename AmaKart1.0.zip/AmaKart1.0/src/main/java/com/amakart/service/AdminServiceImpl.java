package com.amakart.service;

import com.amakart.dto.ProductAttributeDTO;
import com.amakart.model.Cart;
import com.amakart.model.Category;
import com.amakart.model.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;


@Service
public class AdminServiceImpl implements AdminService {


    final String baseURI = "http://localhost:8080/";


    @Autowired
    RestTemplate restTemplate;

    public void addAttributesToProduct(String[] attributes, String productId, HttpHeaders headers) {
        int flag = 2;

        ProductAttributeDTO productAttributeDTO = new ProductAttributeDTO();

        for (int i = 1; i < attributes.length; i += 2) {

            if (flag % 2 == 0) {
                productAttributeDTO = new ProductAttributeDTO();
                productAttributeDTO.setAttributeName(attributes[i]);
            } else {
                productAttributeDTO.setAttributeValue(attributes[i]);

                HttpEntity<?> requestEntity = new HttpEntity<ProductAttributeDTO>(productAttributeDTO, headers);

                restTemplate.exchange(baseURI + "admin/productattributes/" + productId, HttpMethod.POST, requestEntity, Product.class);
            }

            flag++;

        }

    }




    public ModelAndView commonDetails(ModelAndView modelAndView, String jwtKey, HttpServletResponse response) {
        if (jwtKey.equals("")) {

            modelAndView.addObject("User", "Not-Logged In");

        } else {

            HttpHeaders headers = new HttpHeaders();
            headers.add("JWTKey", jwtKey);
            HttpEntity<?> requestEntity = new HttpEntity<String>(headers);

try{
            modelAndView.addObject("User", restTemplate.exchange(baseURI + "/firstname/", HttpMethod.GET, requestEntity, String.class).getBody());

            modelAndView.addObject("CartTotal", restTemplate.exchange(baseURI + "/cart", HttpMethod.GET, requestEntity, Cart.class).getBody().getCartTotal());

            modelAndView.addObject("Cart", restTemplate.exchange(baseURI + "/cart", HttpMethod.GET, requestEntity, Cart.class).getBody().getCartItems());

        }


catch(HttpClientErrorException e)
{
if(e.getStatusCode().value() == 403)
{
    Cookie cookie = new Cookie("JWTKey", jwtKey);
    cookie.setMaxAge(0);
    response.addCookie(cookie);
    modelAndView.addObject("User", "Not-Logged In");

}
}

        }
        try {

            modelAndView.addObject("categoriesList", restTemplate.getForEntity(baseURI + "categories", Category[].class).getBody());

        } catch (final HttpClientErrorException e) {

            if (e.getLocalizedMessage().contains("There are No Categories Present")) {
                modelAndView.setViewName("coming_soon");
            }
        }

        return modelAndView;
    }


    @Override
    public ModelAndView getDisplayOptionsinfo(ModelAndView modelAndView) {
        try {

            restTemplate.getForEntity(baseURI + "categories", Category[].class);
            modelAndView.addObject("categoryStat", "Available");

            restTemplate.getForEntity(baseURI + "subcategories", Category[].class);
            modelAndView.addObject("subCategoryStat", "Available");

            restTemplate.getForEntity(baseURI + "products", Product[].class);
            modelAndView.addObject("productStat", "Available");



        } catch (final HttpClientErrorException e) {
            if (e.getLocalizedMessage().contains("There are No Categories Present.")) {
                modelAndView.addObject("categoryStat", "Not-Present");
                modelAndView.addObject("subCategoryStat", "Not-Present");
                modelAndView.addObject("productStat", "Not-Present");

            }
            if (e.getLocalizedMessage().contains("There are No Sub-Categories Present.")) {

                modelAndView.addObject("subCategoryStat", "Not-Present");
                modelAndView.addObject("productStat", "Not-Present");

            }

            if (e.getLocalizedMessage().contains("There are No Products Present.")) {

                modelAndView.addObject("productStat", "Not-Present");

            }

        }

        return modelAndView;
    }

}
