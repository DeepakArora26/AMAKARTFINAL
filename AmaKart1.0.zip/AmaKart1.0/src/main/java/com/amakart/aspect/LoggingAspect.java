package com.amakart.aspect;


import com.amakart.controller.UserController;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

    private static final Logger LOGGER = LogManager.getLogger(LoggingAspect.class);

    @Before("within(com.amakart.service.*)")
    public void functionLoggingInfo(JoinPoint joinPoint) {

        LOGGER.info(new StringBuilder().append("In the ").append(joinPoint.getSignature().getName()).append(" Function."));

    }


    @Before("within(com.amakart.controller.*)")
    public void controllerLoggingInfo(JoinPoint joinPoint) {

        LOGGER.info(new StringBuilder().append("In the ").append(joinPoint.getSignature().getName()).append(" Controller."));

    }


    @Before("within(com.amakart.restcontroller.*)")
    public void restControllerLoggingInfo(JoinPoint joinPoint) {

        LOGGER.info(new StringBuilder().append("In the ").append(joinPoint.getSignature().getName()).append(" Rest Controller."));

    }


    @AfterThrowing(value = "within(com.amakart..*)", throwing = "exception")
    public void exceptionLoggingInfo(JoinPoint joinPoint, Exception exception) {

        LOGGER.error(new StringBuilder().append(exception.getClass().getSimpleName()).append(" thrown"));

    }


}
