/*
package com.restamakart.restamakart.restcontrollertest;

import com.amakart.exception.*;
import com.amakart.model.Category;
import com.amakart.model.Product;
import com.amakart.restcontroller.RestUserController;
import com.amakart.service.CartService;
import com.amakart.service.ShoppingService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.web.servlet.MockMvc;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


class RestUserControllerTest {




    @InjectMocks
    RestUserController restUserController;


    @Mock
    ShoppingService shopping;

    @Mock
    CartService cartService;


    @Autowired
    private MockMvc mvc;

    static Category category;

    static List<Category> categoriesList = new ArrayList<>();

    static List<Category> subCategoriesList = new ArrayList<>();

    static Product product;

    static List<Product> productsList = new ArrayList<>();

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @BeforeEach
    void initialize() {
        MockitoAnnotations.initMocks(this);
        mvc = MockMvcBuilders.standaloneSetup(restUserController)
                .setControllerAdvice(new ControllerAdvisor())
                .build();
          }






    @BeforeAll
    static void datainit() {


        category = new Category();

        categoriesList = new ArrayList<>();

        category.setParentId(0);
        category.setName("Electronics");
        category.setImage("ABC.jpg");
        category.setId(1);
        categoriesList.add(category);

        category.setParentId(1);
        subCategoriesList.add(category);



        category = new Category();
        category.setParentId(0);
        category.setName("Sports");
        category.setImage("Sports.jpg");
        category.setId(2);

        categoriesList.add(category);


        category.setParentId(1);
        subCategoriesList.add(category);




        product = new Product();
        product.setProductName("Sony TV");
        product.setProductId("1");
        productsList.add(product);




        product = new Product();
        product.setProductName("One Plus TV");
        product.setProductId("2");
        productsList.add(product);






    }




    @Test
    void testGetSubCategories() throws Exception {

        when(shopping.getSubCategories(1)).thenReturn(subCategoriesList);
             mvc.perform(get("/amakart/categories/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.[0]name").value("Electronics"))
                .andExpect(jsonPath("$.[1]name").value("Sports"));

    }

    @Test
    void testGetSubCategoriesWithCategoryNotFoundException() throws Exception {

        when(shopping.getSubCategories(5)).thenThrow(CategoryNotFoundException.class);
        mvc.perform(get("/amakart/categories/5"))
                .andExpect(status().is(404));

    }


    @Test
    void testGetSubCategoriesWithSubCategoriesNotFoundException() throws Exception {

        when(shopping.getSubCategories(5)).thenThrow(SubCategoriesNotFoundException.class);
        mvc.perform(get("/amakart/categories/5"))
                .andExpect(status().is(404));

    }



    @Test
    void testGetCategories() throws Exception {

        when(shopping.getCategories()).thenReturn(categoriesList);
        mvc.perform(get("/amakart/categories"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.[0]name").value("Electronics"))
                .andExpect(jsonPath("$.[1]name").value("Sports"));

    }

    @Test
    void testGetCategoriesWithException() throws Exception {

        when(shopping.getCategories()).thenThrow(CategoriesNotFoundException.class);
        mvc.perform(get("/amakart/categories"))
                .andExpect(status().is(404));

    }




    @Test
    void testGetProducts() throws Exception {

        when(shopping.getProductsList(1)).thenReturn(productsList);
        mvc.perform(get("/amakart/products/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.[0]productName").value("Sony TV"))
                .andExpect(jsonPath("$.[1]productName").value("One Plus TV"));

    }

    @Test
    void testGetProductsWithSubCategoryNotFoundException() throws Exception {

        when(shopping.getProductsList(1)).thenThrow(SubCategoryNotFoundException.class);
        mvc.perform(get("/amakart/products/1"))
                .andExpect(status().is(404));

    }



    @Test
    void testGetProductsWithProductNotFoundException() throws Exception {

        when(shopping.getProductsList(1)).thenThrow(ProductNotFoundException.class);
        mvc.perform(get("/amakart/products/1"))
                .andExpect(status().is(404));

    }



}
*/
