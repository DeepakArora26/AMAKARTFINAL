package com.restamakart.restamakart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestAmakartApplicationTests {

    @Test
    void contextLoads() {
    }

}
