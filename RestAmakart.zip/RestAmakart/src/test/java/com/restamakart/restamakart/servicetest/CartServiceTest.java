package com.restamakart.restamakart.servicetest;


import com.restamakart.restamakart.exception.InsufficientQuantityException;
import com.restamakart.restamakart.exception.InvalidQuantityException;
import com.restamakart.restamakart.exception.ProductNotFoundException;
import com.restamakart.restamakart.exception.ProductNotInCartException;
import com.restamakart.restamakart.model.Cart;
import com.restamakart.restamakart.model.CartItem;
import com.restamakart.restamakart.model.Product;
import com.restamakart.restamakart.repository.CartItemRepository;
import com.restamakart.restamakart.repository.CartRepository;
import com.restamakart.restamakart.repository.ProductRepository;
import com.restamakart.restamakart.service.CartServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class CartServiceTest {

	@InjectMocks
	CartServiceImpl cartServiceImpl;

	@Mock
	ProductRepository productRepository;

	@Mock
	CartItemRepository cartItemRepository;


	@Mock
	CartRepository cartRepository;

	@Mock
	Cart cart;

	@Mock
	Product product;

	@BeforeEach
	void initialize() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testProductQuantityTrue() {

		product = new Product();
		product.setProductAvailableStock(10);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(true, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testProductQuantityFalse() {

		product = new Product();
		product.setProductAvailableStock(1);
		product.setProductId("M1");

		String productId = "M1";
		when(productRepository.findByProductId(productId)).thenReturn(product);

		assertEquals(false, cartServiceImpl.checkProductQuantity(productId, 5));
	}

	@Test
	void testaddToCart() throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cart.addCartItem(cartProduct);

		String productId = "M1";

		when(cartServiceImpl.productExistInCart(productId,"Deepak")).thenReturn(false);
		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(true, cartServiceImpl.addToCart(productId, 10,"Deepak"));

	}


	@Test
	void testaddToCartFalse() throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

		product = new Product();
		product.setProductId("M1");
		product.setThumbnail("ABC.jpg");
		product.setProductName("Sports");
		product.setProductDiscountedPrice(1100.00);
		product.setProductAvailableStock(100);

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cart.addCartItem(cartProduct);

		String productId = "M1";

		when(productRepository.findByProductId(productId)).thenReturn(product);
		assertEquals(false, cartServiceImpl.addToCart(productId, 1000,"Deepak"));

	}



	@Test
	void testproductExistInCartWithNull() throws ProductNotInCartException {
		when(cartItemRepository.findById(1)).thenReturn(Optional.ofNullable(null));
		assertEquals(false, cartServiceImpl.productExistInCart("M1","Deepak"));
	}


	@Test
	void testproductExistInCart() throws ProductNotInCartException {

		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);

		when(cartItemRepository.findById(1)).thenReturn(Optional.ofNullable(cartProduct));
		assertEquals(true, cartServiceImpl.productExistInCart("M1","Deepak"));
	}



	@Test
	void testcheckExistingProductQuantity()
	{
		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);

		when(cartItemRepository.findById(1)).thenReturn(Optional.ofNullable(cartProduct));
		assertEquals(1,cartServiceImpl.checkExistingProductQuantity("M1","Deepak"));
	}


	@Test
	void testcalculateCartTotal()
	{

		cart = new Cart();
		cart.setCartTotal(0.0);
		//cart.setUserId("Dummy");
		CartItem cartProduct = new CartItem();
		cartProduct.setProductId("M1");
		cartProduct.setProductPurchasedQuantity(1);
		cartProduct.setProductPrice(100.0);
		cartProduct.setProductTotalPrice();
		cart.addCartItem(cartProduct);


		cartProduct = new CartItem();
		cartProduct.setProductId("M2");
		cartProduct.setProductPurchasedQuantity(10);
		cartProduct.setProductPrice(200.0);
		cartProduct.setProductTotalPrice();
		cart.addCartItem(cartProduct);


		when(cartItemRepository.findAll()).thenReturn(cart.getCartItems());
		cartServiceImpl.calculateCartTotal("Deepak");
		cartRepository.save(cart);
		assertEquals(0.0,cart.getCartTotal());
	}





}
