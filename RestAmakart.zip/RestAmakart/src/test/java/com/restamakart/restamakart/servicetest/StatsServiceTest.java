package com.restamakart.restamakart.servicetest;


import com.restamakart.restamakart.model.Orders;
import com.restamakart.restamakart.model.User;
import com.restamakart.restamakart.repository.OrdersRepository;
import com.restamakart.restamakart.repository.ProductRepository;
import com.restamakart.restamakart.repository.UserRepository;
import com.restamakart.restamakart.service.StatsServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

class StatsServiceTest {

    @InjectMocks
    StatsServiceImpl statsService;

    @Mock
    OrdersRepository ordersRepository;


    @Mock
    UserRepository userRepository;


    @Mock
    ProductRepository productRepository;



    @BeforeEach
    void initialize() {
        MockitoAnnotations.initMocks(this);
    }


    @Test
    void testCalculateOrderCount() {

        when(ordersRepository.findAll()).thenReturn(new ArrayList<>());
        assertEquals(0, statsService.calculateOrderCount());

    }


    @Test
    void testCalculateOrderCountWithValue() {

        List<Orders> ordersList = new ArrayList<>();
        ordersList.add(new Orders());
        ordersList.add(new Orders());
        ordersList.add(new Orders());

        when(ordersRepository.findAll()).thenReturn(ordersList);
        assertEquals(3, statsService.calculateOrderCount());

    }


    @Test
    void testCalculateTotalRegisteredUsers() {

        when(userRepository.findAll()).thenReturn(new ArrayList<>());
        assertEquals(0, statsService.calculateTotalRegisteredUsers());

    }



    @Test
    void testCalculateTotalRegisteredUsersWithValue() {

        List<User> userList = new ArrayList<>();
        userList.add(new User());
        userList.add(new User());

        when(userRepository.findAll()).thenReturn(userList);
        assertEquals(2, statsService.calculateTotalRegisteredUsers());

    }



}