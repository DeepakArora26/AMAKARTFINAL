package com.restamakart.restamakart.dto;

import javax.validation.constraints.NotEmpty;

public class ProductAttributeDTO {

    @NotEmpty(message = "Attribute Name is required")
    private String attributeName;
    @NotEmpty(message = "Attribute Value is required")
    private String attributeValue;

    public ProductAttributeDTO() {
    }

    public String getAttributeName() {
        return attributeName;
    }

    public void setAttributeName(String attributeName) {
        this.attributeName = attributeName;
    }

    public String getAttributeValue() {
        return attributeValue;
    }

    public void setAttributeValue(String attributeValue) {
        this.attributeValue = attributeValue;
    }
}
