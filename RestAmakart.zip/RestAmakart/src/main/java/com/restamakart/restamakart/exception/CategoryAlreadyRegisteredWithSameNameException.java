package com.restamakart.restamakart.exception;

public class CategoryAlreadyRegisteredWithSameNameException extends Exception {
    public CategoryAlreadyRegisteredWithSameNameException() {
        super();
    }
}
