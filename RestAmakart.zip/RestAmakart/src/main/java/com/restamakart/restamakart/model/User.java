package com.restamakart.restamakart.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Entity
@Component
public class User {

    @Id
    private String emailId;
    private String fullName;
    private String password;
    private String role;
    @OneToOne(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER,orphanRemoval=true)
    @JsonIgnore
    private Cart cart;
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    @JsonIgnore
    private List<Orders> orders = new ArrayList<>();





    public User() {
    }

    public User(String emailId, String password, String role, String fullName) {
        this.emailId = emailId;
        this.password = password;
        this.role = role;
        this.fullName = fullName;
    }


    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String username) {
        this.emailId = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }


    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public List<Orders> getOrders() {
        return orders;
    }

    public void setOrders(List<Orders> orders) {
        this.orders = orders;
    }

    public void addCart(Cart cart) {
        cart.setUser(this);
        this.cart = cart;
    }

    public void addOrder(Orders order)
    {
        order.setUser(this);
        orders.add(order);
    }


    @Override
    public String toString() {
        return "User{" +
                "username='" + emailId + '\'' +
                ", fullName='" + fullName + '\'' +
                ", password='" + password + '\'' +
                ", role='" + role + '\'' +
                '}';
    }


}
