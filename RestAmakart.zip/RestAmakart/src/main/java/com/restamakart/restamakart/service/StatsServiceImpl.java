package com.restamakart.restamakart.service;


import com.restamakart.restamakart.exception.NoOrdersPresentException;
import com.restamakart.restamakart.model.Orders;
import com.restamakart.restamakart.model.Product;
import com.restamakart.restamakart.repository.OrdersRepository;
import com.restamakart.restamakart.repository.ProductRepository;
import com.restamakart.restamakart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StatsServiceImpl implements StatsService {


    @Autowired
    OrdersRepository ordersRepository;


    @Autowired
    UserRepository userRepository;


    @Autowired
    ProductRepository productRepository;


    @Override
    public int calculateOrderCount() {
        return ordersRepository.findAll().size();

    }

    @Override
    public int calculateTotalRegisteredUsers() {
        return userRepository.findAll().size();
    }

    @Override
    public List<Orders> getLastFiveOrders() throws NoOrdersPresentException {
        if(ordersRepository.findFirst5ByOrderNoIsNotNullOrderByOrderNoDesc().isEmpty())
        {
            throw new NoOrdersPresentException();
        }


      return ordersRepository.findFirst5ByOrderNoIsNotNullOrderByOrderNoDesc();
    }

    @Override
    public List<Product> getLastAddedProducts() {
        return productRepository.findFirst4ByProductIdIsNotNullOrderByProductIdDesc();
    }
}
