package com.restamakart.restamakart.exception;

@SuppressWarnings("serial")
public class EmptyCartException extends Exception {

	public EmptyCartException() {
		super();
	}
}
