package com.restamakart.restamakart.exception;

public class CategoryNotFoundException extends Exception {
    public CategoryNotFoundException() {
        super();
    }
}
