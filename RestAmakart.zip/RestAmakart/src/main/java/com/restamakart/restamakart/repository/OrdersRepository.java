package com.restamakart.restamakart.repository;

import com.restamakart.restamakart.model.Orders;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface OrdersRepository extends JpaRepository<Orders, Integer> {


    List<Orders> findFirst5ByOrderNoIsNotNullOrderByOrderNoDesc();



}
