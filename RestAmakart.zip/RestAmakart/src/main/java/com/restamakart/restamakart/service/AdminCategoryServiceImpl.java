package com.restamakart.restamakart.service;


import com.restamakart.restamakart.dto.CategoryDTO;
import com.restamakart.restamakart.dto.ProductAttributeDTO;
import com.restamakart.restamakart.dto.ProductDTO;
import com.restamakart.restamakart.dto.SubCategoryDTO;
import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Category;
import com.restamakart.restamakart.model.Product;
import com.restamakart.restamakart.model.ProductAttribute;
import com.restamakart.restamakart.repository.CategoryRepository;
import com.restamakart.restamakart.repository.ProductRepository;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
public class AdminCategoryServiceImpl implements AdminCategoryService {


    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    ModelMapper modelMapper;


    @Override
    public Category addNewCategory(CategoryDTO categoryDTO) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {

        Category category = modelMapper.map(categoryDTO, Category.class);
        category.setParentId(0);

        checkIfNameCategoryExists(categoryDTO.getName(), null);

        return categoryRepository.save(category);

    }

    @Override
    public Category addNewSubCategory(int categoryId, SubCategoryDTO subCategoryDTO) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException, CategoryNotFoundException {


        Category category = categoryRepository.findByIdAndParentId(categoryId, 0);

        if (category == null) {
            throw new CategoryNotFoundException();
        }

        checkIfNameCategoryExists(subCategoryDTO.getName(), null);

        category = new Category();
        category = modelMapper.map(subCategoryDTO, Category.class);
        category.setParentId(categoryId);
        return categoryRepository.save(category);
    }


    @Override
    public Product addNewProduct(int subCategoryId, ProductDTO productDTO) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException, SubCategoryNotFoundException {


        Product product = modelMapper.map(productDTO, Product.class);

        Category subCategory = categoryRepository.findByIdAndParentIdIsGreaterThan(subCategoryId, 0);

        if (subCategory == null) {
            throw new SubCategoryNotFoundException();
        }

        checkIfProductNameExists(productDTO.getProductName(), productDTO.getProductId(), null,null);

        product.setCategory(subCategory);

        return productRepository.save(product);

    }

    @Override
    public Product addAttributesToProduct(String productId, ProductAttributeDTO productAttributeDTO) throws ProductNotFoundException {

        Product product = productRepository.findByProductId(productId);

        if(product == null)
        {
            throw new ProductNotFoundException();
        }

        ProductAttribute productAttribute = new ProductAttribute();
        productAttribute.setAttributeName(productAttributeDTO.getAttributeName());
        productAttribute.setAttributeValue(productAttributeDTO.getAttributeValue());
        productAttribute.setProduct(product);
        product.addAttribute(productAttribute);
          return productRepository.save(product);


    }





    @Override
    public boolean removeCategory(int categoryId) throws CategoryNotFoundException {

        boolean flag = false;

        Category category = categoryRepository.findByIdAndParentId(categoryId, 0);

        if (category == null) {
            throw new CategoryNotFoundException();
        }

        List<Category> subCategories = categoryRepository.findByparentId(category.getId());

        categoryRepository.delete(category);

        for (int i = 0; i < subCategories.size(); i++) {
            categoryRepository.delete(subCategories.get(i));
        }

        flag = true;

        return flag;

    }


    @Override
    public boolean removeSubCategory(int subCategoryId) throws SubCategoryNotFoundException {
        boolean flag = false;

        Category subCategory = categoryRepository.findByIdAndParentIdIsGreaterThan(subCategoryId, 0);

        if (subCategory == null) {
            throw new SubCategoryNotFoundException();
        }

        categoryRepository.delete(subCategory);
        flag = true;

        return flag;
    }

    @Override
    public Category updateCategory(int categoryId, CategoryDTO categoryDTO) throws CategoryNotFoundException, CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {

        Category category = categoryRepository.findById(categoryId);

        if (category == null) {
            throw new CategoryNotFoundException();
        }


        checkIfNameCategoryExists(categoryDTO.getName(), category.getName());

        category.setName(categoryDTO.getName());
        category.setPromoted(categoryDTO.isPromoted());
        category.setPromotedThumbnail(categoryDTO.getPromotedThumbnail());
        return categoryRepository.save(category);

    }

    @Override
    public Category updateSubCategory(int subCategoryId, SubCategoryDTO subCategoryDTO) throws SubCategoryNotFoundException, CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {

        Category subCategory = categoryRepository.findByIdAndParentIdIsGreaterThan(subCategoryId, 0);

        if (subCategory == null) {
            throw new SubCategoryNotFoundException();
        }


        checkIfNameCategoryExists(subCategoryDTO.getName(), subCategory.getName());


        subCategory.setImage(subCategoryDTO.getImage());
        subCategory.setName(subCategoryDTO.getName());
        return categoryRepository.save(subCategory);

    }

    @Override
    public void checkIfNameCategoryExists(String name, String originalName) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {


        if (!name.equals(originalName)) {
            if (categoryRepository.findByNameAndParentId(name, 0) != null) {

                throw new CategoryAlreadyRegisteredWithSameNameException();
            }


            if (categoryRepository.findByNameAndParentIdIsGreaterThan(name, 0) != null) {

                throw new SubCategoryAlreadyRegisteredWithSameNameException();

            }

        }
    }

    @Override
    public boolean removeProduct(String productId) throws ProductNotFoundException {

        Product product = productRepository.findByProductId(productId);


        if (product == null) {
            throw new ProductNotFoundException();
        }

        Category subCategory = categoryRepository.findById(product.getCategory().getId());
        subCategory.getProducts().remove(product);
        categoryRepository.save(subCategory);
        productRepository.delete(product);
        return true;
    }

    @Override
    public Product updateProduct(String productId, ProductDTO productDTO) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException, ProductNotFoundException {

        Product product = productRepository.findByProductId(productId);

        if (product == null) {
            throw new ProductNotFoundException();
        }

        checkIfProductNameExists(productDTO.getProductName(), productDTO.getProductId(), product.getProductName(),productId);

        product.setProductId(productDTO.getProductId());
        product.setProductName(productDTO.getProductName());
        product.setProductAvailableStock(productDTO.getProductAvailableStock());
        product.setProductMrp(productDTO.getProductMrp());
        product.setProductDiscountedPrice(productDTO.getProductDiscountedPrice());
        product.setThumbnail(productDTO.getThumbnail());

        return productRepository.save(product);


    }

    @Override
    public void checkIfProductNameExists(String productName, String productId, String originalName, String originalProductId) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException {




            if (productRepository.findByProductName(productName) != null && !productName.equals(originalName)) {

                throw new ProductAlreadyRegisteredWithSameNameException();

            }



            if (productRepository.findById(productId).isPresent() && !productId.equals(originalProductId)) {

                throw new ProductAlreadyRegisteredWithSameIdException();

            }

        }





}


