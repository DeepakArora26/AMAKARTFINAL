package com.restamakart.restamakart.repository;

import com.restamakart.restamakart.model.Category;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;


@Repository
public interface CategoryRepository extends JpaRepository<Category, Integer> {

	List<Category> findByparentId(int parendId);

	Category findById(int id);

	@Query(value = " SELECT * FROM category where promoted=1 LIMIT 1 offset 0", nativeQuery = true)
	Category findFirstPromotedCategory();

	@Query(value = " SELECT * FROM category where parent_id=0 LIMIT 1 offset 0", nativeQuery = true)
	Category findFirstCategory();


	@Query(value = " SELECT * FROM category c where c.parent_id = 0 and c.id = ?1" , nativeQuery = true)
	Category findCategory(int catgeoryId);

	Category findByName(String categoryName);

	Category findByNameAndParentId(String categoryName, int parentId);

	Category findByNameAndParentIdIsGreaterThan(String categoryName, int value);

	List<Category> findByParentIdGreaterThan(int value);

	Category findByIdAndParentIdIsGreaterThan(int subCategoryId,int parentId);

	Category findByIdAndParentId(int categoryId,int parentId);


}
