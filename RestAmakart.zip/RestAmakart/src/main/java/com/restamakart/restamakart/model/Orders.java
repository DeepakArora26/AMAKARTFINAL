package com.restamakart.restamakart.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@Entity
@Component
public class Orders {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderNo;
	private Double cartTotal;
	private Date orderDate;
	@OneToMany(mappedBy = "orderHistory", cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<OrderItem> orderDetailList = new ArrayList<>();
	@ManyToOne
	@JsonIgnore
	private User user;

	public int getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(int orderNo) {
		this.orderNo = orderNo;
	}


	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public List<OrderItem> getOrderDetailList() {
		return orderDetailList;
	}

	public void addProduct(OrderItem orderdetail) {
		orderdetail.setOrderHistory(this);
		orderDetailList.add(orderdetail);
	}

	public void setOrderDetailList(List<OrderItem> orderDetailList) {
		this.orderDetailList = orderDetailList;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "OrderHistory [orderNo=" + orderNo + ", cartTotal=" + cartTotal
				+ ", orderDate=" + orderDate + ", orderDetailList=" + orderDetailList + "]";
	}

}
