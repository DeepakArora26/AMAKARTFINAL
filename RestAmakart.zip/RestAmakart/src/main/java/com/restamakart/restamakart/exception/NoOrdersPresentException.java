package com.restamakart.restamakart.exception;

public class NoOrdersPresentException extends Exception {

    public NoOrdersPresentException() {
        super();
    }
}
