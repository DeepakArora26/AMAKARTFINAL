package com.restamakart.restamakart.exception;

@SuppressWarnings("serial")
public class InsufficientQuantityException extends Exception {

	public InsufficientQuantityException() {
		super();
	}
}
