package com.restamakart.restamakart.exception;

public class InvalidQuantityException extends Exception {
    public InvalidQuantityException() {
        super();
    }
}
