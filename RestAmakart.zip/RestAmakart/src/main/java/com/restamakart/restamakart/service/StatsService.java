package com.restamakart.restamakart.service;



import com.restamakart.restamakart.exception.NoOrdersPresentException;
import com.restamakart.restamakart.model.Orders;
import com.restamakart.restamakart.model.Product;

import java.util.List;

public interface StatsService {

   int calculateOrderCount();

   int calculateTotalRegisteredUsers();

   List<Orders> getLastFiveOrders() throws NoOrdersPresentException;

   List<Product> getLastAddedProducts();

}
