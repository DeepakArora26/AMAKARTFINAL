package com.restamakart.restamakart.restapi;


import com.restamakart.restamakart.dto.CategoryDTO;
import com.restamakart.restamakart.dto.ProductAttributeDTO;
import com.restamakart.restamakart.dto.ProductDTO;
import com.restamakart.restamakart.dto.SubCategoryDTO;
import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Category;
import com.restamakart.restamakart.model.Product;
import com.restamakart.restamakart.service.AdminCategoryService;
import com.restamakart.restamakart.service.RegisterService;
import com.restamakart.restamakart.service.StatsService;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/admin")
@Api(value = "Admin Resource", description = "Rest EndPoints Related to Admin <style>.models {display: none !important}</style>")
public class AdminApi {



    @Autowired
    StatsService statsService;

    @Autowired
    AdminCategoryService adminCategoryService;

    @Autowired
    RegisterService registerService;

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves The Last 5 Placed Orders in Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Last 5 Orders"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/stats/orders")
    public ResponseEntity orderStats() throws NoOrdersPresentException {

        return ResponseEntity.ok().body(statsService.getLastFiveOrders());

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves The Last Few Added Products into the Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Last Few Added Products"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/stats/products")
    public ResponseEntity productStats() {

        return ResponseEntity.ok().body(statsService.getLastAddedProducts());

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves The Total Order Count Of Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Order Count of Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/stats/ordercount")
    public ResponseEntity productCountStats() {

        Map<String,Object> body = new LinkedHashMap<>();
        body.put("Order Count",statsService.calculateOrderCount());

        return ResponseEntity.ok().body(body);

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves The Total Registered User Count Of Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Registered User Count of Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/stats/usercount")
    public ResponseEntity userCountStats() {

        Map<String,Object> body = new LinkedHashMap<>();
        body.put("User Count",statsService.calculateTotalRegisteredUsers());


        return ResponseEntity.ok().body(body);

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds The Category in the Amakart",response = Category.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Added the Category in Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/category")
    public ResponseEntity addCategory(@RequestBody @Valid CategoryDTO categoryDTO) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {

        return ResponseEntity.ok().body(adminCategoryService.addNewCategory(categoryDTO));

    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Removes The Category, all it's related Sub-Categories and the Products from the Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Deleted the Category from the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @DeleteMapping("/category/{categoryId}")
    public ResponseEntity removeCategory(@ApiParam(value = "Category ID for which the Category will be Deleted", required = true) @PathVariable int categoryId) throws CategoryNotFoundException {

        adminCategoryService.removeCategory(categoryId);
        Map<String,Object> body = new LinkedHashMap<>();
        body.put("message","All the related Sub-Categories and it's Products have been deleted");
        return ResponseEntity.ok().body(body);

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Updates The Category in the Amakart with the Given Category Id")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updated the Category in the Amakart",response = Category.class),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PutMapping("/category/{categoryId}")
    public ResponseEntity updateCategory(@RequestBody @Valid CategoryDTO categoryDTO,@ApiParam(value = "Category ID for which the Category will be Updated", required = true) @PathVariable int categoryId) throws CategoryNotFoundException, CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException {

        return ResponseEntity.ok().body(adminCategoryService.updateCategory(categoryId,categoryDTO));

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds The Sub-Category in the Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Added the Sub-Category in the Amakart",response = Category.class),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/subcategory/{categoryId}")
    public ResponseEntity addSubCategory(@RequestBody @Valid SubCategoryDTO subCategoryDTO,@ApiParam(value = "Category ID for which the Sub-Category will be Added", required = true)  @PathVariable int categoryId) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException, CategoryNotFoundException {

        return ResponseEntity.ok().body(adminCategoryService.addNewSubCategory(categoryId,subCategoryDTO));

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Deletes The Sub-Category from the Amakart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Deleted the Sub-Category from the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @DeleteMapping("/subcategory/{subCategoryId}")
    public ResponseEntity removeSubCategory(@ApiParam(value = "Sub-Category ID for which the Sub-Category will be Deleted", required = true) @PathVariable int subCategoryId) throws SubCategoryNotFoundException {


        adminCategoryService.removeSubCategory(subCategoryId);
        Map<String,Object> body = new LinkedHashMap<>();
        body.put("message","All the related Products have been deleted");
        return ResponseEntity.ok().body(body);

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Updates The Sub-Category in the Amakart With Given Sub-Category Id",response = Category.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updates the Sub-Category in the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PutMapping("/subcategory/{subCategoryId}")
    public ResponseEntity updateSubCategory(@RequestBody @Valid SubCategoryDTO subCategoryDTO,@ApiParam(value = "Sub-Category ID for which the Sub-Category will be Updated", required = true) @PathVariable int subCategoryId) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException, SubCategoryNotFoundException {

        return ResponseEntity.ok().body(adminCategoryService.updateSubCategory(subCategoryId,subCategoryDTO));

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds The Product in the Amakart With Given Sub-Category Id",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Added the Product in the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/product/{subCategoryId}")
    public ResponseEntity addProduct(@RequestBody @Valid ProductDTO productDTO,@ApiParam(value = "Sub-Category ID for which the Product will be Added", required = true)@PathVariable int subCategoryId) throws ProductAlreadyRegisteredWithSameIdException, SubCategoryNotFoundException, ProductAlreadyRegisteredWithSameNameException {

        return ResponseEntity.ok().body(adminCategoryService.addNewProduct(subCategoryId,productDTO));

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds The Product Attributes in the Product With Given Product Id",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Added the Product Attributes in the Product"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/productattributes/{productId}")
    public ResponseEntity addProduct(@RequestBody @Valid ProductAttributeDTO productAttributeDTO, @ApiParam(value = "Product ID for which the Product Attributes will be Added", required = true)@PathVariable String productId) throws ProductNotFoundException {

        return ResponseEntity.ok().body(adminCategoryService.addAttributesToProduct(productId,productAttributeDTO));

    }




    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Deletes The Product from the Amakart With Given Product Id")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Deleted the Product from the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @DeleteMapping("/product/{productId}")
    public ResponseEntity removeProduct(@ApiParam(value = "Product ID for which the Product will be Deleted", required = true) @PathVariable String productId) throws ProductNotFoundException {

        adminCategoryService.removeProduct(productId);

        Map<String,Object> body = new LinkedHashMap<>();
        body.put("message","Product And all it's related Attributes And Images Have Been Deleted");
        return ResponseEntity.ok().body(body);



    }



    @GetMapping("/firstname")
    public ResponseEntity getFirstName(Principal principal) {

        return ResponseEntity.ok().body(registerService.getFirstName(principal.getName()));
    }




    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Updates The Product in the Amakart With Given Product Id")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updated the Product in the Amakart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PutMapping("/product/{productId}")
    public ResponseEntity updateProduct(@RequestBody @Valid ProductDTO productDTO,@ApiParam(value = "Product ID for which the Product will be Updated", required = true)  @PathVariable String productId) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException, ProductNotFoundException {

        return ResponseEntity.ok().body(adminCategoryService.updateProduct(productId,productDTO));

    }





}
