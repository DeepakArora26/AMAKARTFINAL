package com.restamakart.restamakart.service;



import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Category;
import com.restamakart.restamakart.model.Product;

import java.util.List;

public interface ShoppingService {

	List<Category> getCategories() throws CategoriesNotFoundException;

	List<Category> getSubCategories(int parentId) throws SubCategoriesNotFoundException, CategoryNotFoundException;

	boolean isCategoryInvalid(int parentId) throws CategoryNotFoundException;

	List<Product> getProductsList(int subCategoryId) throws ProductsNotFoundException, SubCategoryNotFoundException;

	Product getProductDetail(String productId) throws ProductNotFoundException;

	String getCategoryName(int id) throws CategoryNotFoundException;

	Category getPromotedCategory() throws FirstPromotedCategoryNotFoundException;

	List<Category> getPromotedSubCategories() throws SubCategoriesNotFoundException, CategoryNotFoundException, FirstPromotedCategoryNotFoundException;

	String getCategoryNameOfSubCategory(int subCategoryId) throws CategoryNotFoundException;

    String getSubCategoryNameFromProductId(String productId) throws ProductNotFoundException;

	String getCategoryNameFromProductId(String productId) throws CategoryNotFoundException, ProductNotFoundException;

	List<Category> getAllSubCategories() throws SubCategoriesNotFoundException;

	boolean logout(String jwtToken);

    List<Product> getAllProducts() throws ProductsNotFoundException;
}
