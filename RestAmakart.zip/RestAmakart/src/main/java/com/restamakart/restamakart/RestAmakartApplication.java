package com.restamakart.restamakart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestAmakartApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestAmakartApplication.class, args);
    }

}
