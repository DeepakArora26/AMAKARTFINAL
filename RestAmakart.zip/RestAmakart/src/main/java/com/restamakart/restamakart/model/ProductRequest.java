package com.restamakart.restamakart.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;

public class ProductRequest {


    @Min(value = 1, message = "Product Quantity Cannot be <=0")
    int quantity;


    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
