package com.restamakart.restamakart.service;


import com.restamakart.restamakart.dto.UserDTO;
import com.restamakart.restamakart.exception.UserNameAlreadyRegisteredException;
import com.restamakart.restamakart.model.User;

public interface RegisterService {

    void registerUser(UserDTO userDTO) throws UserNameAlreadyRegisteredException;

    String getFirstName(String userName);


}
