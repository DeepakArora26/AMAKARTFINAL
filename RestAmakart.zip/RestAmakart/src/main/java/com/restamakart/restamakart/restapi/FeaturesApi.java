package com.restamakart.restamakart.restapi;


import com.restamakart.restamakart.exception.CategoryNotFoundException;
import com.restamakart.restamakart.exception.FirstPromotedCategoryNotFoundException;
import com.restamakart.restamakart.exception.ProductNotFoundException;
import com.restamakart.restamakart.exception.SubCategoriesNotFoundException;

import com.restamakart.restamakart.model.AuthenticationRequest;
import com.restamakart.restamakart.model.AuthenticationResponse;
import com.restamakart.restamakart.service.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.Map;


@RestController
@RequestMapping("/features")
public class FeaturesApi {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    CustomUserService customUserService;

    @Autowired
    JwtUtil jwtToken;

    @Autowired
    ShoppingService shopping;

    @Autowired
    CartService cartService;

    @Autowired
    RegisterService registerService;

    @GetMapping("/promotedcategory")
    public ResponseEntity getPromotedCategory() throws FirstPromotedCategoryNotFoundException {

        return ResponseEntity.ok().body(shopping.getPromotedCategory());

    }


    @PostMapping("/categoryname")
    public ResponseEntity getCategoryName(@RequestBody Map<String,Integer> categoryName) throws CategoryNotFoundException {

        int id = 0;

        for (Map.Entry<String, Integer> entry : categoryName.entrySet()) {
           id = entry.getValue();
           break;
        }
        return ResponseEntity.ok().body(shopping.getCategoryName(id));
    }


    @PostMapping("/categorynameofsubcategory")
    public ResponseEntity getCategoryNameOfSubCategory(@RequestBody Map<String,Integer> subCategoryName) throws CategoryNotFoundException {

        return ResponseEntity.ok().body(shopping.getCategoryNameOfSubCategory(subCategoryName.get("subCategoryId")));
    }

    @PostMapping("/categorynameofproduct")
    public ResponseEntity getCategoryNameOfProduct(@RequestBody Map<String,String> product) throws CategoryNotFoundException, ProductNotFoundException {

        return ResponseEntity.ok().body(shopping.getCategoryNameFromProductId(product.get("productId")));
    }

    @PostMapping("/subcategorynameofproduct")
    public ResponseEntity getSubCategoryNameOfProduct(@RequestBody Map<String,String> product) throws  ProductNotFoundException {

        return ResponseEntity.ok().body(shopping.getSubCategoryNameFromProductId(product.get("productId")));
    }





    @GetMapping("/promotedsubcategories")
    public ResponseEntity getPromotedSubCategories() throws FirstPromotedCategoryNotFoundException, CategoryNotFoundException, SubCategoriesNotFoundException {

        return ResponseEntity.ok().body(shopping.getPromotedSubCategories());
    }





    @PostMapping("/genrateJWT")
    public ResponseEntity getTokenUI(@RequestBody AuthenticationRequest authenticationRequest) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
        } catch (BadCredentialsException e) {
            throw new Exception("Incorrect", e);
        }

        final UserDetails userDetails = customUserService.loadUserByUsername(authenticationRequest.getUsername());

        final String jwt = jwtToken.generateToken(userDetails);

        return ResponseEntity.ok().body(new AuthenticationResponse(jwt));

    }






}
