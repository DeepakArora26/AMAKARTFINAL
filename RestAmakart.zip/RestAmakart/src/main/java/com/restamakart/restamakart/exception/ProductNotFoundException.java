package com.restamakart.restamakart.exception;

public class ProductNotFoundException extends Exception {

    public ProductNotFoundException() {
        super();
    }
}
