package com.restamakart.restamakart.exception;

public class ProductNotInCartException extends Exception {
    public ProductNotInCartException() {
        super();
    }
}
