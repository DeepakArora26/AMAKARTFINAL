package com.restamakart.restamakart.dto;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

public class UserDTO {


    @NotEmpty(message = "Email-Id is required")
    @Email
    private String emailId;
    @NotEmpty(message = "Full Name is required")
    private String fullName;
    @NotEmpty(message = "Password is required")
    private String password;


    public UserDTO() {
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
