package com.restamakart.restamakart.exception;

public class SubCategoryNotFoundException extends Exception {
    public SubCategoryNotFoundException() {
        super();
    }
}
