package com.restamakart.restamakart.exception;

public class ProductAlreadyRegisteredWithSameIdException extends Exception {
    public ProductAlreadyRegisteredWithSameIdException() {
        super();
    }
}
