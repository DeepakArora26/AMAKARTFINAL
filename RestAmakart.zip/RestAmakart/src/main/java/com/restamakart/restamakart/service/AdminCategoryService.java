package com.restamakart.restamakart.service;


import com.restamakart.restamakart.dto.CategoryDTO;
import com.restamakart.restamakart.dto.ProductAttributeDTO;
import com.restamakart.restamakart.dto.ProductDTO;
import com.restamakart.restamakart.dto.SubCategoryDTO;
import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Category;
import com.restamakart.restamakart.model.Product;

public interface AdminCategoryService {

    Category addNewCategory(CategoryDTO category) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException;

    Category addNewSubCategory(int categoryId,SubCategoryDTO subCategoryDTO) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException, CategoryNotFoundException;

    Product addNewProduct(int subCategoryId,ProductDTO productDTO) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException, SubCategoryNotFoundException;

    Product addAttributesToProduct(String productId, ProductAttributeDTO productAttributeDTO) throws ProductNotFoundException;

    boolean removeCategory(int categoryId) throws CategoryNotFoundException;

    boolean removeSubCategory(int subCategoryId) throws SubCategoryNotFoundException;

    Category updateCategory(int categoryId,CategoryDTO category) throws CategoryNotFoundException, CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException;

    Category updateSubCategory(int subCategoryId, SubCategoryDTO subCategoryDTO) throws SubCategoryNotFoundException, CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException;

    void checkIfNameCategoryExists(String name,String originalName) throws CategoryAlreadyRegisteredWithSameNameException, SubCategoryAlreadyRegisteredWithSameNameException;

    boolean removeProduct(String productId) throws ProductNotFoundException;

    Product updateProduct(String productId, ProductDTO productDTO) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException, ProductNotFoundException;

    void checkIfProductNameExists(String productName,String productId,String originalName,String originalProductId) throws ProductAlreadyRegisteredWithSameNameException, ProductAlreadyRegisteredWithSameIdException ;


}
