package com.restamakart.restamakart.exception;

@SuppressWarnings("serial")
public class SubCategoriesNotFoundException extends Exception {

	public SubCategoriesNotFoundException() {
		super();
	}
}
