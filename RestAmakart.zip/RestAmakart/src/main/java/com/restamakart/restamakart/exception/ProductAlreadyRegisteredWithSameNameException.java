package com.restamakart.restamakart.exception;

public class ProductAlreadyRegisteredWithSameNameException extends Exception {

    public ProductAlreadyRegisteredWithSameNameException() {
        super();
    }
}
