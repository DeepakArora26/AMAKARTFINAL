package com.restamakart.restamakart.exception;

public class FirstPromotedCategoryNotFoundException extends Exception {
    public FirstPromotedCategoryNotFoundException() {
        super();
    }
}
