package com.restamakart.restamakart.exception;

@SuppressWarnings("serial")
public class ProductsNotFoundException extends Exception {

	public ProductsNotFoundException() {
		super();
	}
}
