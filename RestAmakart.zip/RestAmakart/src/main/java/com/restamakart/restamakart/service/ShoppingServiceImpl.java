package com.restamakart.restamakart.service;

import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Category;
import com.restamakart.restamakart.model.JwtToken;
import com.restamakart.restamakart.model.Product;
import com.restamakart.restamakart.repository.CategoryRepository;
import com.restamakart.restamakart.repository.JwtTokenRepository;
import com.restamakart.restamakart.repository.ProductRepository;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;

@Service
public class ShoppingServiceImpl implements ShoppingService {

    private static final Logger LOGGER = LogManager.getLogger(ShoppingServiceImpl.class);

    @Autowired
    CategoryRepository categoryRepository;

    @Autowired
    ProductRepository productRepository;

    @Resource
    private ShoppingService shoppingService;

    @Autowired
    JwtTokenRepository jwtTokenRepository;

    @Autowired
    ModelMapper modelMapper;




    @Override
    public List<Category> getCategories() throws CategoriesNotFoundException {


        List<Category> categories = categoryRepository.findByparentId(0);

        if (categories.isEmpty()) {

            throw new CategoriesNotFoundException();

        }

        return categories;

    }


    @Override
    public List<Category> getSubCategories(int parentId) throws SubCategoriesNotFoundException, CategoryNotFoundException {


        if (shoppingService.isCategoryInvalid(parentId)) {

            throw new CategoryNotFoundException();

        }

        List<Category> categories = categoryRepository.findByparentId(parentId);

        if (categories.isEmpty()) {


            throw new SubCategoriesNotFoundException();

        }

        return categories;
    }

    @Override
    public boolean isCategoryInvalid(int parentId) {


        boolean result = false;


        if (categoryRepository.findCategory(parentId) == null) {


            LOGGER.error("--------Category Invalid ----------");

            result = true;

        }

        return result;

    }

    @Override
    public List<Product> getProductsList(int subCategoryId) throws ProductsNotFoundException, SubCategoryNotFoundException {


        Category category = categoryRepository.findByIdAndParentIdIsGreaterThan(subCategoryId,0);

        if (category == null) {

            throw new SubCategoryNotFoundException();
        }

        List<Product> productList = category.getProducts();

        if (productList.isEmpty()) {


            throw new ProductsNotFoundException();

        }

        return productList;

    }

    @Override
    public Product getProductDetail(String productId) throws ProductNotFoundException {


        Product product = productRepository.findByProductId(productId);

        if (product == null) {


            throw new ProductNotFoundException();

        }

        return product;
    }

    @Override
    public String getCategoryName(int id) throws CategoryNotFoundException {

Category category = categoryRepository.findById(id);

    if(category == null)
    {
        throw new CategoryNotFoundException();
    }

        return category.getName();

    }


    @Override
    public Category getPromotedCategory() throws FirstPromotedCategoryNotFoundException {


        Category category = categoryRepository.findFirstPromotedCategory();

        if (category == null) {

            LOGGER.info("--------First Promoted Category Not Found Returning First Category----------");

            category = categoryRepository.findFirstCategory();

            if (category == null) {

                throw new FirstPromotedCategoryNotFoundException();
            }
        }

        return category;
    }

    @Override
    public List<Category> getPromotedSubCategories() throws SubCategoriesNotFoundException, CategoryNotFoundException, FirstPromotedCategoryNotFoundException {


        return shoppingService.getSubCategories(shoppingService.getPromotedCategory().getId());

    }


    @Override
    public String getCategoryNameOfSubCategory(int subCategoryId) throws CategoryNotFoundException {



        Category category = categoryRepository.findById(subCategoryId);

        if(category == null)
        {
            throw new CategoryNotFoundException();
        }


        return categoryRepository.findById(category.getParentId()).getName();

    }

    @Override
    public String getSubCategoryNameFromProductId(String productId) throws ProductNotFoundException {

        Product product =  productRepository.findById(productId).get();
        if(product == null)
        {
            throw new ProductNotFoundException();
        }

        return product.getCategory().getName();

    }

    @Override
    public String getCategoryNameFromProductId(String productId) throws ProductNotFoundException, CategoryNotFoundException {


        Product product =  productRepository.findById(productId).get();

        if(product == null)
        {
            throw new ProductNotFoundException();
        }


        int categoryId = product.getCategory().getParentId();

        return shoppingService.getCategoryName(categoryId);

    }

    @Override
    public List<Category> getAllSubCategories() throws SubCategoriesNotFoundException {

        List<Category> subCategories = categoryRepository.findByParentIdGreaterThan(0);

        if(subCategories.isEmpty())
        {
            throw new SubCategoriesNotFoundException();
        }

        return subCategories;
    }

    @Override
    public boolean logout(String jwtToken) {

        JwtToken jwt = new JwtToken();
        jwt.setInvalidJwtToken(jwtToken);
        jwtTokenRepository.save(jwt);

        return true;
    }

    @Override
    public List<Product> getAllProducts() throws ProductsNotFoundException {

        List<Product> productList = productRepository.findAll();
            if(productList.isEmpty())
            {
                throw new ProductsNotFoundException();
            }

            return productList;
    }

}
