package com.restamakart.restamakart.apiadvice;

import com.restamakart.restamakart.exception.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;


@ControllerAdvice
public class ApiAdvisor extends ResponseEntityExceptionHandler {

	final String message = "Message";
	
	 @ExceptionHandler(CategoriesNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleCategoriesNotFound(CategoriesNotFoundException exception)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put(message,"There are No Categories Present.");
	        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	    }




	@ExceptionHandler(CategoryNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleCategoryNotFound(CategoryNotFoundException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Category Not Found With Given Id");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}



	@ExceptionHandler(SubCategoriesNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleSubCategoriesNotFound(SubCategoriesNotFoundException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"There are No Sub-Categories Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}



	@ExceptionHandler(SubCategoryNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleSubCategoryNotFound(SubCategoryNotFoundException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Sub Category Not Found With Given Id");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}




	@ExceptionHandler(ProductsNotFoundException.class)
	    public ResponseEntity<Map<String, Object>> handleProductsNotFound(ProductsNotFoundException exception)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put(message,"There are No Products Present.");
	        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	    }




	@ExceptionHandler(ProductNotFoundException.class)
	public ResponseEntity<Map<String, Object>> handleProductNotFound(ProductNotFoundException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Product Not Found With Given Id");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(ProductNotInCartException.class)
	public ResponseEntity<Map<String, Object>> handleProductNotInCart(ProductNotInCartException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Product With Given Id Not Found In Cart.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(ProductAlreadyRegisteredWithSameNameException.class)
	public ResponseEntity<Map<String, Object>> handleProductNotInCart(ProductAlreadyRegisteredWithSameNameException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Product With Given Name Is Already Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}



	@ExceptionHandler(ProductAlreadyRegisteredWithSameIdException.class)
	public ResponseEntity<Map<String, Object>> handleProductNotInCart(ProductAlreadyRegisteredWithSameIdException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Product With Given Id Is Already Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InsufficientQuantityException.class)
	    public ResponseEntity<Map<String, Object>> handleInsufficientQuantity(InsufficientQuantityException exception)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put(message,"Sorry. We don't have this much quantity in stock now.");
	        return new ResponseEntity<>(body, HttpStatus.NOT_ACCEPTABLE);
	    }



	@ExceptionHandler(InvalidQuantityException.class)
	public ResponseEntity<Map<String, Object>> handleInvalidQuantityFound(InvalidQuantityException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Sorry. Quantity Cannot be in <=0.");
		return new ResponseEntity<>(body, HttpStatus.NOT_ACCEPTABLE);
	}



	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> errorList = ex
				.getBindingResult()
				.getFieldErrors()
				.stream()
				.map(fieldError -> fieldError.getDefaultMessage())
				.collect(Collectors.toList());
		return handleExceptionInternal(ex, errorList, headers, HttpStatus.BAD_REQUEST, request);
	}




	@ExceptionHandler(EmptyCartException.class)
	    public ResponseEntity<Map<String, Object>> handleEmptyCart(EmptyCartException exception)
	    {
	        Map<String,Object> body = new LinkedHashMap<>();
	        body.put(message,"Cart Is Empty");
	        return new ResponseEntity<>(body, HttpStatus.OK);
	    }



	@ExceptionHandler(CategoryAlreadyRegisteredWithSameNameException.class)
	public ResponseEntity<Map<String, Object>> handleCategoryAlreadyPresentWithSameName(CategoryAlreadyRegisteredWithSameNameException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Category With Same Name is Already Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(SubCategoryAlreadyRegisteredWithSameNameException.class)
	public ResponseEntity<Map<String, Object>> handleSubCategoryAlreadyPresentWithSameName(SubCategoryAlreadyRegisteredWithSameNameException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"Sub-Category With Same Name is Already Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(NoOrdersPresentException.class)
	public ResponseEntity<Map<String, Object>> handleOrdersNotFound(NoOrdersPresentException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"There are No Orders Present.");
		return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
	}


	@ExceptionHandler(UserNameAlreadyRegisteredException.class)
	public ResponseEntity<Map<String, Object>> handleOrdersNotFound(UserNameAlreadyRegisteredException exception)
	{
		Map<String,Object> body = new LinkedHashMap<>();
		body.put(message,"UserName Already Exists.");
		return new ResponseEntity<>(body, HttpStatus.NOT_ACCEPTABLE);
	}

}
