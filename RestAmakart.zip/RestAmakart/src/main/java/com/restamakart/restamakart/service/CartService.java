package com.restamakart.restamakart.service;


import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.Cart;
import com.restamakart.restamakart.model.CartItem;
import com.restamakart.restamakart.model.Orders;
import com.restamakart.restamakart.model.User;

import java.util.List;

public interface CartService {

	boolean addToCart(String productId, int productQuantity, String userName) throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException;

	boolean checkProductQuantity(String productId, int productQuantity);

	void calculateCartTotal(String userName);

	boolean productExistInCart(String productId, String userName) throws ProductNotInCartException;

	int checkExistingProductQuantity(String productId, String userName);

	Orders checkout(String userName) throws InsufficientQuantityException, EmptyCartException;

	Cart getCart(String userName) throws EmptyCartException;

	void initializeCart(String userName);

	boolean deleteCartItem(String productId, String userName) throws ProductNotInCartException;

	boolean updateProductQuantity(String productId, int productQuantity, String userName) throws InsufficientQuantityException, ProductNotInCartException, InvalidQuantityException;

	boolean addNewProduct(String productId, int productQuantity, String userName) throws ProductsNotFoundException, InsufficientQuantityException;

	void validateEmptyCart(String userName) throws EmptyCartException;

	List<String> validateCartItemsQuantity(String userName);

    void removeOutOfStockProducts(String userName);

    void makeCartItemOutOfStock(String productId, String userName);

	 void validateProduct(String productId) throws ProductNotFoundException;

	 void validateProductQuantity(int productQuantity) throws InvalidQuantityException;

	 User getUser(String userName);

	 void convertCartItemToOrder(CartItem productDetail, String userName);


}
