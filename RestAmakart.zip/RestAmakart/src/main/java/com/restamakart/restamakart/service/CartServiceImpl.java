package com.restamakart.restamakart.service;

import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.*;
import com.restamakart.restamakart.repository.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service
public class CartServiceImpl implements CartService {

    private static final Logger LOGGER = LogManager.getLogger(CartServiceImpl.class);

    @Resource
	private CartService cartService;

    @Autowired
    CartItem cartItem;

    @Autowired
    ProductRepository productRepository;

    @Autowired
    Product product;

    @Autowired
    OrderItem orderItem;

    @Autowired
    Orders order;

    @Autowired
    OrdersRepository orderRepository;

    @Autowired
    CartItemRepository cartItemRepository;

    @Autowired
    CartRepository cartRepository;

    @Autowired
    Cart cart;

    @Autowired
    UserRepository userRepository;

    @Autowired
    User user;


    @Override
    public boolean addToCart(String productId, int productQuantity, String userName)
            throws InsufficientQuantityException, ProductNotFoundException, InvalidQuantityException, ProductNotInCartException {


        cartService.validateProductQuantity(productQuantity);

		cartService.validateProduct(productId);


        boolean flag = false;

        cart = getCart(userName);

        cartItem = new CartItem();

        if (cartService.productExistInCart(productId, userName)) {

            LOGGER.info("--------Product Exists In Cart----------");

            productQuantity += cartService.checkExistingProductQuantity(productId, userName);

            flag = updateProductQuantity(productId, productQuantity, userName);
        } else {

            LOGGER.info("--------Adding New Product To Cart----------");
            flag = addNewProduct(productId, productQuantity, userName);
            cartService.calculateCartTotal(userName);

        }


        return flag;
    }

    @Override
    public void validateProduct(String productId) throws ProductNotFoundException {


        if (!productRepository.findById(productId).isPresent()) {

            throw new ProductNotFoundException();
        }
    }

    @Override
    public void validateProductQuantity(int productQuantity) throws InvalidQuantityException {



        if (productQuantity <= 0) {

            throw new InvalidQuantityException();
        }
    }

    @Override
    public void calculateCartTotal(String userName) {


        Double cartTotal = 0.0;

        cart = getCart(userName);

        for (CartItem currentProduct : cart.getCartItems()) {

            cartTotal = cartTotal + currentProduct.getProductTotalPrice();
        }


        cart.setCartTotal(cartTotal);

        cartRepository.save(cart);

    }

    @Override
    public boolean checkProductQuantity(String productId, int productQuantity) {


        return (productRepository.findByProductId(productId).getProductAvailableStock() >= productQuantity);

    }

    @Override
    public boolean productExistInCart(String productId, String userName) throws ProductNotInCartException {


        boolean result = false;

        if (cartItemRepository.findByProductIdAndCart_Id(productId, getCart(userName).getId()) != null) {

            LOGGER.info("--------Product Exist In Cart----------");

            result = true;
        }


        return result;

    }

    @Override
    public int checkExistingProductQuantity(String productId, String userName) {


        return cartItemRepository.findByProductIdAndCart_Id(productId, getCart(userName).getId()).getProductPurchasedQuantity();

    }

    @Override
    public Orders checkout(String userName) throws InsufficientQuantityException, EmptyCartException {


        validateEmptyCart(userName);

        cart = getCart(userName);
        order = new Orders();


        List<String> result = cartService.validateCartItemsQuantity(userName);

        if (result.isEmpty()) {

            for (CartItem productDetail : cart.getCartItems()) {

                cartService.convertCartItemToOrder(productDetail, userName);

            }

            cart.getCartItems().clear();
            cartRepository.save(cart);

            order.setCartTotal(getCart(userName).getCartTotal());
            long millis = System.currentTimeMillis();
            java.sql.Date date = new java.sql.Date(millis);

            order.setOrderDate(date);
            order.setUser(cartService.getUser(userName));
            orderRepository.save(order);
            initializeCart(userName);


        } else if (result.size() > 0) {
            throw new InsufficientQuantityException();
        }


        return order;
    }


	@Override
    public User getUser(String userName) {
        return userRepository.findByEmailId(userName);
    }

	@Override
    public void convertCartItemToOrder(CartItem productDetail, String userName) {


        if (cartService.checkProductQuantity(productDetail.getProductId(), productDetail.getProductPurchasedQuantity())) {

            orderItem = new OrderItem();

            product = productRepository.findByProductId(productDetail.getProductId());
            orderItem.setProductId(productDetail.getProductId());
            orderItem.setProductImage(productDetail.getProductImage());
            orderItem.setProductName(productDetail.getProductName());
            orderItem.setProductPrice(productDetail.getProductPrice());
            orderItem.setProductPurchasedQuantity(productDetail.getProductPurchasedQuantity());
            orderItem.setProductTotalPrice(productDetail.getProductTotalPrice());
            order.addProduct(orderItem);
            product.setProductAvailableStock(product.getProductAvailableStock() - orderItem.getProductPurchasedQuantity());

        }


    }

	@Override
    public List<String> validateCartItemsQuantity(String userName) {

        cart = getCart(userName);

        List<String> result = new ArrayList<>();

        for (CartItem productInCart : cart.getCartItems()) {
            if (!cartService.checkProductQuantity(productInCart.getProductId(), productInCart.getProductPurchasedQuantity())) {
                result.add(productInCart.getProductId());
                cartService.makeCartItemOutOfStock(productInCart.getProductId(), userName);
            }

        }

        return result;
    }

    @Override
    public void makeCartItemOutOfStock(String productId, String userName) {

        cartItem = cartItemRepository.findByProductIdAndCart_Id(productId, getCart(userName).getId());
        cartItem.setOutOfStock(true);
        cartItemRepository.save(cartItem);

    }

    @Override
    public void removeOutOfStockProducts(String userName) {

        cart = getCart(userName);

        List<CartItem> cartItems = cart.getCartItems();

        for (int i=0;cartItems.size()>0 && i<cartItems.size();i++) {
            if (cartItems.get(i).isOutOfStock()) {
                getCart(userName).getCartItems().remove(cartItemRepository.findByProductIdAndCart_Id(cartItem.getProductId(), getCart(userName).getId()));
                cartRepository.save(cart);
                cartService.calculateCartTotal(userName);
            }

        }

    }


    public void validateEmptyCart(String userName) throws EmptyCartException {



        cart = getCart(userName);

        if (cart.getCartTotal() == 0.0) {
            throw new EmptyCartException();
        }
    }

    @Override
    public Cart getCart(String userName) {


        if (cartService.getUser(userName).getCart() == null) {
            initializeCart(userName);
        }

        return cartService.getUser(userName).getCart();

    }


    @Override
    public void initializeCart(String userName) {

        cart = new Cart();
        cart.setCartTotal(0.0);
        cartService.getUser(userName).addCart(cart);
        cartRepository.save(cart);

    }

    @Override
    public boolean deleteCartItem(String productId, String userName) throws ProductNotInCartException {


        if (!cartService.productExistInCart(productId, userName)) {
            throw new ProductNotInCartException();
        }

        cartItemRepository.deleteByCart_IdAndAndProductId(getCart(userName).getId(), productId);
        cartService.calculateCartTotal(userName);


        return true;
    }

    @Override
    public boolean updateProductQuantity(String productId, int productQuantity, String userName) throws InsufficientQuantityException, ProductNotInCartException, InvalidQuantityException {



        cartService.validateProductQuantity(productQuantity);

        validateCartProduct(productId, userName);

        if (cartService.checkProductQuantity(productId, productQuantity)) {

            cartItem = cartItemRepository.findByProductIdAndCart_Id(productId, getCart(userName).getId());
            cartItem.setProductPurchasedQuantity(productQuantity);
            cartItem.setProductTotalPrice();
            cartItemRepository.save(cartItem);
            cartService.calculateCartTotal(userName);

        } else {

            throw new InsufficientQuantityException();

        }

        return true;

    }

    public void validateCartProduct(String productId, String userName) throws ProductNotInCartException {



        if (!cartService.productExistInCart(productId, userName)) {

            throw new ProductNotInCartException();
        }
    }

    @Override
    public boolean addNewProduct(String productId, int productQuantity, String userName) throws InsufficientQuantityException {


        if (cartService.checkProductQuantity(productId, productQuantity)) {

            cart = getCart(userName);
            cartItem = new CartItem();
            product = productRepository.findByProductId(productId);
            cartItem.setProductId(product.getProductId());
            cartItem.setProductImage(product.getThumbnail());
            cartItem.setProductName(product.getProductName());
            cartItem.setProductPrice(product.getProductDiscountedPrice());
            cartItem.setProductPurchasedQuantity(productQuantity);
            cartItem.setProductTotalPrice();
            cart.addCartItem(cartItem);
            cartItemRepository.save(cartItem);

        } else {


            throw new InsufficientQuantityException();

        }

        return true;
    }

}
