package com.restamakart.restamakart.exception;

public class UserNameAlreadyRegisteredException extends Exception {
    public UserNameAlreadyRegisteredException() {
        super();
    }
}
