package com.restamakart.restamakart.exception;

public class SubCategoryAlreadyRegisteredWithSameNameException extends Exception {
    public SubCategoryAlreadyRegisteredWithSameNameException() {
        super();
    }
}
