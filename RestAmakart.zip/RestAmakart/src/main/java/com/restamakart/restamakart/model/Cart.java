package com.restamakart.restamakart.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import org.springframework.stereotype.Component;

import javax.persistence.*;
import java.util.ArrayList;
import java.util.List;

@Component
@Entity
public class Cart {


	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	@OneToOne(cascade = CascadeType.ALL,fetch = FetchType.EAGER)
	@JsonIgnore
	User user;
	@OneToMany(mappedBy = "cart", cascade = CascadeType.ALL,orphanRemoval=true)
	private List<CartItem> cartItems = new ArrayList<>();
	private Double cartTotal;


	public Cart() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public List<CartItem> getCartItems() {
		return cartItems;
	}

	public void setCartItems(List<CartItem> cartItems) {
		this.cartItems = cartItems;
	}

	public Double getCartTotal() {
		return cartTotal;
	}

	public void setCartTotal(Double cartTotal) {
		this.cartTotal = cartTotal;
	}

	public void addCartItem(CartItem cartItem)
	{
		cartItem.setCart(this);
		cartItems.add(cartItem);
	}


	public void removeCartItem(CartItem cartItem)
	{
		cartItems.remove(cartItem);
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Cart{" +
				"id=" + id +
				", cartItems=" + cartItems +
				", cartTotal=" + cartTotal +
				'}';
	}
}
