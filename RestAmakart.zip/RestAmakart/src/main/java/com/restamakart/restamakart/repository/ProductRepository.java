package com.restamakart.restamakart.repository;


import com.restamakart.restamakart.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, String> {

	Product findByProductId(String productId);

	List<Product> findFirst4ByProductIdIsNotNullOrderByProductIdDesc();

	Product findByProductName(String productName);


}
