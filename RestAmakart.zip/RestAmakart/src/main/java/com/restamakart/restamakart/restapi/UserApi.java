package com.restamakart.restamakart.restapi;


import com.restamakart.restamakart.dto.UserDTO;
import com.restamakart.restamakart.exception.*;
import com.restamakart.restamakart.model.*;
import com.restamakart.restamakart.service.*;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.security.Principal;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@Api(value = "User Resource", description = "Rest EndPoints Related to Users <style>.models {display: none !important}</style>")
public class UserApi {


    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    CustomUserService customUserService;

    @Autowired
    JwtUtil jwtToken;

    @Autowired
    ShoppingService shopping;

    @Autowired
    CartService cartService;

    @Autowired
    RegisterService registerService;

    @Autowired
    JwtUtil jwtUtil;

     String message = "Message";

    @ApiOperation(value = "Authenticate The User And Returns the JWT Token for Further Authorization",response = AuthenticationResponse.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the JWT Token"),
            @ApiResponse(code = 403, message = "Bad Credentials")
    })
    @PostMapping("/authentication")
    public ResponseEntity getToken(@RequestBody @Valid AuthenticationRequest authenticationRequest) throws Exception {
        try {
            authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
        } catch (BadCredentialsException e) {
            throw new Exception("Incorrect", e);
        }


        final UserDetails userDetails = customUserService.loadUserByUsername(authenticationRequest.getUsername());

        final String jwt = jwtToken.generateToken(userDetails);

        return ResponseEntity.ok().body(new AuthenticationResponse(jwt));

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves All the Categories",response = Category.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Categories List"),
            @ApiResponse(code = 404, message = "There Are No Categories Present")
    })
    @GetMapping("/categories")
    public ResponseEntity getCategories() throws CategoriesNotFoundException {

        return ResponseEntity.ok().body(shopping.getCategories());

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves All the Sub-Categories",response = Category.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Sub-Categories List"),
            @ApiResponse(code = 404, message = "There Are No Sub-Categories Present")
    })
    @GetMapping("/subcategories")
    public ResponseEntity getAllSubCategories() throws SubCategoriesNotFoundException {

        return ResponseEntity.ok().body(shopping.getAllSubCategories());

    }




    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves All the Sub-Categories Present Under The Given Category Id",response = Category.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Sub-Categories List"),
            @ApiResponse(code = 404, message = "There Are No Sub-Categories Present")
    })
    @GetMapping("categories/{id}")
    public ResponseEntity getSubCategories(@ApiParam(value = "Category ID for which the Sub-Categories will be retrieved", required = true) @PathVariable(value = "id") int parentId) throws CategoryNotFoundException, SubCategoriesNotFoundException {

        return ResponseEntity.ok().body(shopping.getSubCategories(parentId));
    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves All the Products Present Under The Given Sub-Category Id",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Products List"),
            @ApiResponse(code = 404, message = "There Are No Products Present")
    })
    @GetMapping("{subCategoryid}/products")
    public ResponseEntity getProducts(@ApiParam(value = "Sub-Category ID for which the Products will be retrieved", required = true) @PathVariable(value = "subCategoryid") int subcategoryId)
            throws ProductsNotFoundException, SubCategoryNotFoundException {

        return ResponseEntity.ok().body(shopping.getProductsList(subcategoryId));

    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves All the Products Present In Amakart",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Products List"),
            @ApiResponse(code = 404, message = "There Are No Products Present")
    })
    @GetMapping("products")
    public ResponseEntity getProducts()
            throws ProductsNotFoundException {

        return ResponseEntity.ok().body(shopping.getAllProducts());

    }


    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves the Product Detail Present Under The Given Product Id",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully retrieved the Product"),
            @ApiResponse(code = 404, message = "There Is No Product Present with Given Id")
    })
    @GetMapping("product/{productId}")
    public ResponseEntity getProductDetail(@ApiParam(value = "Product ID for which the Product Detail will be retrieved", required = true) @PathVariable(value = "productId") String productId)
            throws ProductNotFoundException {

        return ResponseEntity.ok().body(shopping.getProductDetail(productId));

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds the Product With Given Id and Quantity into User's Cart",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully Added the Product Into The Cart"),
            @ApiResponse(code = 404, message = "Product Not Found With The Given Id"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/cart/product/{productId}")
    public ResponseEntity addProductToCart(@RequestBody @Valid ProductRequest product,@ApiParam(value = "Product ID for which the Products will be Added into the Cart", required = true) @PathVariable String productId, Principal principal) throws InsufficientQuantityException, ProductNotFoundException, ProductNotInCartException, InvalidQuantityException {

        cartService.addToCart(productId, product.getQuantity(), principal.getName());

        Map<String,Object> body = new LinkedHashMap<>();
        body.put(message,"Product Has Been Added To Your Cart");
        return ResponseEntity.status(201).body(body);

    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Removes the Product With Given Id From User's Cart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Deleted the Product From The Cart"),
            @ApiResponse(code = 404, message = "Product Not Found With The Given Id"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @DeleteMapping("/cart/product/{productId}")
    public ResponseEntity removeProductFromCart(@ApiParam(value = "Product ID for which the Products will be Deleted from the Cart", required = true)  @PathVariable String productId,Principal principal) throws ProductNotInCartException {


        	cartService.deleteCartItem(productId,principal.getName());

        Map<String,Object> body = new LinkedHashMap<>();
        body.put(message,"Product Has Been Removed From Your Cart");
          return ResponseEntity.ok().body(body);

    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Updates the Product With Given Quantity And Provided Id Into User's Cart")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Updated the Product Into The Cart"),
            @ApiResponse(code = 404, message = "Product Not Found With The Given Id"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PutMapping("/cart/product/{productId}")
    public ResponseEntity updateCart(@ApiParam(value = "Product ID for which the Products will be Updated into the Cart", required = true)  @PathVariable String productId,@RequestBody ProductRequest product,Principal principal) throws InsufficientQuantityException, ProductNotInCartException, InvalidQuantityException {


        cartService.updateProductQuantity(productId, product.getQuantity(),principal.getName());
        Map<String,Object> body = new LinkedHashMap<>();
        body.put(message,"Product Has Been Updated In Your Cart");
        return ResponseEntity.ok().body(body);

    }

    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Retrieves the Cart Items from the User's Cart",response = Cart.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Retrieved the Product From The Cart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/cart")
    public ResponseEntity<Cart> showCart(Principal principal) throws EmptyCartException {

        return ResponseEntity.ok().body(cartService.getCart(principal.getName()));

    }




    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Logs Out The User",response = Boolean.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successful Log-Out"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @PostMapping("/logoutToken")
    public ResponseEntity logout(@RequestBody JwtToken jwt) {

        return ResponseEntity.ok().body(shopping.logout(jwt.getInvalidJwtToken()));

    }


    @ApiOperation(value = "Retrieves The Role",response = Boolean.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Retrieved the Role"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/role")
    public ResponseEntity getRole() {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();

        return ResponseEntity.ok().body(auth.getAuthorities().toArray()[0]);

    }



    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Deletes the Out Of Stock Item From User's Cart",response = Cart.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Deleted the Out Of Stock Product From The Cart"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @DeleteMapping("cart/removeoutofstock")
    public ResponseEntity removeOutOfStockProducts(Principal principal)  {

        cartService.removeOutOfStockProducts(principal.getName());

        return ResponseEntity.ok().body("Deleted");

    }






    @GetMapping("/firstname")
    public ResponseEntity getFirstName(Principal principal) {


        return ResponseEntity.ok().body(registerService.getFirstName(principal.getName()));
    }






    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Places your Order with Given Cart Items to AmaKart Website",response = Orders.class)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Successfully Placed The Order"),
            @ApiResponse(code = 403, message = "User Is Not Allowed To Use This")
    })
    @GetMapping("/checkout")
    public ResponseEntity checkout(Principal principal) throws InsufficientQuantityException, EmptyCartException {

        return ResponseEntity.ok().body(cartService.checkout(principal.getName()));
    }




    @SuppressWarnings("rawtypes")
    @ApiOperation(value = "Adds the User to the Amakart",response = Product.class)
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Successfully Added the User"),
            @ApiResponse(code = 406, message = "User Already Present With the Given Email Id"),
    })
    @PostMapping("/register")
    public ResponseEntity registerUser(@RequestBody @Valid UserDTO userDTO) throws UserNameAlreadyRegisteredException {

        registerService.registerUser(userDTO);

        return ResponseEntity.status(201).body("Registered As User");

    }


}
