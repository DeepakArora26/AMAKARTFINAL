
package com.restamakart.restamakart.exception;

@SuppressWarnings("serial")
public class CategoriesNotFoundException extends Exception {

	public CategoriesNotFoundException() {
		super();
	}
}
