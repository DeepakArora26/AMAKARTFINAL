package com.restamakart.restamakart.repository;

import com.restamakart.restamakart.model.JwtToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JwtTokenRepository extends JpaRepository<JwtToken,Integer> {

    JwtToken findByInvalidJwtToken(String jwtToken);
}
