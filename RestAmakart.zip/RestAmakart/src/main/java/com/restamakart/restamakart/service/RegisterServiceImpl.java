package com.restamakart.restamakart.service;


import com.restamakart.restamakart.dto.UserDTO;
import com.restamakart.restamakart.exception.UserNameAlreadyRegisteredException;
import com.restamakart.restamakart.model.User;
import com.restamakart.restamakart.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class RegisterServiceImpl implements RegisterService {


    @Autowired
    UserRepository userRepository;

    @Autowired
    User user;

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    CartService cartService;


    @Override
    public void registerUser(UserDTO userDTO) throws UserNameAlreadyRegisteredException {


        if (userRepository.findByEmailId(userDTO.getEmailId()) != null) {

            throw new UserNameAlreadyRegisteredException();
        }


            user = new User();
            user.setEmailId(userDTO.getEmailId());
            user.setFullName(userDTO.getFullName());
            user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
            user.setRole("USER");
            userRepository.save(user);
            cartService.initializeCart(user.getEmailId());
            user = null;

    }

    @Override
    public String getFirstName(String userName) {
        return userRepository.findByEmailId(userName).getFullName().split(" ")[0];

    }




}
